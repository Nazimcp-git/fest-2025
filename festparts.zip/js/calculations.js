// js/calculations.js
// Business-logic helpers for computing scores and penalties.

/**
 * Returns a map of { teamId: totalPenaltyPoints } for all teams.
 * @returns {Object}
 */
function calculateTeamPenalties() {
  const penaltiesByTeam = {};
  for (const teamId in appData.teams) {
    penaltiesByTeam[teamId] = 0;
  }
  Object.values(appData.teamPenalties || {}).forEach(penalty => {
    if (penaltiesByTeam.hasOwnProperty(penalty.teamId)) {
      penaltiesByTeam[penalty.teamId] += penalty.points;
    }
  });
  return penaltiesByTeam;
}

/**
 * Recalculates every student's totalPoints and every team's
 * teamDirectScores from published results, then writes the
 * updates to Firebase in a single batch.
 * @returns {Promise}
 */
async function recalculateAllPoints() {
  const publishedResults = getDataAsArray("results").filter(r => r.status === "published");

  // Initialise accumulators
  const studentPoints   = {};
  const teamDirectPoints = {};

  Object.keys(appData.students || {}).forEach(id => { studentPoints[id] = 0; });
  Object.keys(appData.teams    || {}).forEach(id => {
    teamDirectPoints[id] = {};
    CATEGORIES.forEach(cat => { teamDirectPoints[id][cat] = 0; });
  });

  for (const result of publishedResults) {
    if (!result.participants || result.participants.length === 0) continue;

    const cfg = result.programType === 'group'
      ? appData.groupPointsConfig
      : result.programType === 'team'
        ? appData.teamPointsConfig
        : appData.pointsConfig;

    result.participants.forEach(participant => {
      let pts = 0;
      if (participant.position && participant.position !== 'none' && cfg[participant.position])
        pts += cfg[participant.position];
      if (participant.grade && participant.grade !== "none" && cfg[participant.grade])
        pts += cfg[participant.grade];

      if (result.programType === 'group' || result.programType === 'team') {
        const student = appData.students[participant.studentId];
        if (student && student.teamId && teamDirectPoints[student.teamId] && result.category) {
          if (teamDirectPoints[student.teamId][result.category] === undefined)
            teamDirectPoints[student.teamId][result.category] = 0;
          teamDirectPoints[student.teamId][result.category] += pts;
        }
      } else {
        if (studentPoints.hasOwnProperty(participant.studentId))
          studentPoints[participant.studentId] += pts;
      }
    });
  }

  const updates = {};
  for (const studentId in studentPoints)
    updates[`/students/${studentId}/totalPoints`] = studentPoints[studentId];
  for (const teamId in teamDirectPoints)
    updates[`/teamDirectScores/${teamId}`] = teamDirectPoints[teamId];

  return db.ref().update(updates);
}

/**
 * Calculates scores from ALL results (pending + ready + published).
 * Used by the internal admin Dashboard tab — shows live unfiltered scores.
 * @returns {{ teamsArray: Array, studentsArray: Array }}
 */
function calculateAllScoresInternal() {
    const studentPoints    = {};
    const teamDirectPoints = {};
    const teamPenalties    = calculateTeamPenalties();

    for (const studentId in appData.students) { studentPoints[studentId] = 0; }
    for (const teamId in appData.teams) {
        teamDirectPoints[teamId] = {};
        CATEGORIES.forEach(cat => { teamDirectPoints[teamId][cat] = 0; });
    }

    const allResults = appData.results || {};
    for (const resultId in allResults) {
        const result = allResults[resultId];
        if (!result.participants) continue;

        const cfg = result.programType === 'group'
            ? appData.groupPointsConfig
            : result.programType === 'team'
                ? appData.teamPointsConfig
                : appData.pointsConfig;

        result.participants.forEach(participant => {
            let points = 0;
            if (participant.position && participant.position !== "none" && cfg[participant.position])
                points += cfg[participant.position];
            if (participant.grade && participant.grade !== "none" && cfg[participant.grade])
                points += cfg[participant.grade];

            if (result.programType === 'group' || result.programType === 'team') {
                const student = appData.students[participant.studentId];
                if (student && student.teamId && teamDirectPoints[student.teamId] && result.category) {
                    if (!teamDirectPoints[student.teamId][result.category])
                        teamDirectPoints[student.teamId][result.category] = 0;
                    teamDirectPoints[student.teamId][result.category] += points;
                }
            } else {
                if (studentPoints.hasOwnProperty(participant.studentId))
                    studentPoints[participant.studentId] += points;
            }
        });
    }

    const teamsArray    = JSON.parse(JSON.stringify(getDataAsArray("teams")));
    const studentsArray = JSON.parse(JSON.stringify(getDataAsArray("students")));

    studentsArray.forEach(student => {
        student.totalPoints = studentPoints[student.id] || 0;
    });

    teamsArray.forEach(team => {
        const directScores = teamDirectPoints[team.id] || {};
        let totalDirectPoints = 0;
        team.categoryPoints = {};
        CATEGORIES.forEach(cat => {
            const pts = directScores[cat] || 0;
            team.categoryPoints[cat] = pts;
            totalDirectPoints += pts;
        });
        team.totalPoints = totalDirectPoints;

        studentsArray.forEach(student => {
            if (student.teamId === team.id) {
                team.totalPoints += student.totalPoints;
                if (student.category && team.categoryPoints.hasOwnProperty(student.category))
                    team.categoryPoints[student.category] += student.totalPoints;
            }
        });

        team.totalPoints -= (teamPenalties[team.id] || 0);
    });

    teamsArray.sort((a, b) => b.totalPoints - a.totalPoints);
    studentsArray.sort((a, b) => (b.totalPoints || 0) - (a.totalPoints || 0));

    return { teamsArray, studentsArray };
}

/**
 * Calculates scores from published + "ready" results only.
 * Used by the Score Preview tab — shows projected scores before final publish.
 * @returns {{ teamsArray: Array, studentsArray: Array }}
 */
function getProvisionalScores() {
    const studentPoints    = {};
    const teamDirectPoints = {};
    const teamPenalties    = calculateTeamPenalties();

    for (const studentId in appData.students) { studentPoints[studentId] = 0; }
    for (const teamId in appData.teams) {
        teamDirectPoints[teamId] = {};
        CATEGORIES.forEach(cat => { teamDirectPoints[teamId][cat] = 0; });
    }

    const allResults = appData.results || {};
    for (const resultId in allResults) {
        const result = allResults[resultId];
        if ((result.status !== "published" && result.status !== "ready") || !result.participants)
            continue;

        const cfg = result.programType === 'group'
            ? appData.groupPointsConfig
            : result.programType === 'team'
                ? appData.teamPointsConfig
                : appData.pointsConfig;

        result.participants.forEach(participant => {
            let points = 0;
            if (participant.position && participant.position !== "none" && cfg[participant.position])
                points += cfg[participant.position];
            if (participant.grade && participant.grade !== "none" && cfg[participant.grade])
                points += cfg[participant.grade];

            if (result.programType === 'group' || result.programType === 'team') {
                const student = appData.students[participant.studentId];
                if (student && student.teamId && teamDirectPoints[student.teamId] && result.category) {
                    if (!teamDirectPoints[student.teamId][result.category])
                        teamDirectPoints[student.teamId][result.category] = 0;
                    teamDirectPoints[student.teamId][result.category] += points;
                }
            } else {
                if (studentPoints.hasOwnProperty(participant.studentId))
                    studentPoints[participant.studentId] += points;
            }
        });
    }

    const teamsArray    = JSON.parse(JSON.stringify(getDataAsArray("teams")));
    const studentsArray = JSON.parse(JSON.stringify(getDataAsArray("students")));

    studentsArray.forEach(student => {
        student.totalPoints = studentPoints[student.id] || 0;
    });

    teamsArray.forEach(team => {
        const directScores = teamDirectPoints[team.id] || {};
        let totalDirectPoints = 0;
        team.categoryPoints = {};
        CATEGORIES.forEach(cat => {
            const pts = directScores[cat] || 0;
            team.categoryPoints[cat] = pts;
            totalDirectPoints += pts;
        });
        team.totalPoints = totalDirectPoints;

        studentsArray.forEach(student => {
            if (student.teamId === team.id) {
                team.totalPoints += student.totalPoints;
                if (student.category && team.categoryPoints.hasOwnProperty(student.category))
                    team.categoryPoints[student.category] += student.totalPoints;
            }
        });

        team.totalPoints -= (teamPenalties[team.id] || 0);
    });

    teamsArray.sort((a, b) => b.totalPoints - a.totalPoints);
    studentsArray.sort((a, b) => (b.totalPoints || 0) - (a.totalPoints || 0));

    return { teamsArray, studentsArray };
}
