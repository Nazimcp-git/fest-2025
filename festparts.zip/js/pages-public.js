// js/pages-public.js
// Public-facing page render functions.
// Each returns an HTML string that is injected into #main-content.

async function renderHomePage() {
            const teamsArray = getDataAsArray("teams");
            const teamPenalties = calculateTeamPenalties();

            teamsArray.forEach(team => {
                const directScores = appData.teamDirectScores[team.id] || {};
                let totalDirectPoints = 0;
                for (const cat in directScores) {
                    totalDirectPoints += (directScores[cat] || 0);
                }
                team.totalPoints = totalDirectPoints;

                team.categoryPoints = {};
                CATEGORIES.forEach(cat => {
                    team.categoryPoints[cat] = directScores[cat] || 0;
                });
            });

            const studentsArray = getDataAsArray("students");
            studentsArray.forEach(student => {
                const team = teamsArray.find(t => t.id === student.teamId);
                if (team) {
                    const studentPoints = student.totalPoints || 0;
                    team.totalPoints += studentPoints;
                    if (student.category && team.categoryPoints.hasOwnProperty(student.category)) {
                        team.categoryPoints[student.category] += studentPoints;
                    }
                }
            });

            teamsArray.forEach(team => {
                team.totalPoints -= (teamPenalties[team.id] || 0);
            });

            teamsArray.sort((a, b) => b.totalPoints - a.totalPoints);

            const categoryToppers = [];
            CATEGORIES.forEach(category => {
                const studentsInCategory = studentsArray.filter(s => s.category === category);
                if (studentsInCategory.length > 0) {
                    studentsInCategory.sort((a, b) => (b.totalPoints || 0) - (a.totalPoints || 0));
                    const topper = studentsInCategory[0];
                    if (topper && (topper.totalPoints || 0) > 0) {
                        categoryToppers.push({
                            category: category,
                            id: topper.id,
                            name: topper.name,
                            points: topper.totalPoints,
                            teamName: appData.teams[topper.teamId]?.name || 'N/A'
                        });
                    }
                }
            });

            const classScores = {};
            studentsArray.forEach(student => {
                if (student.class && student.class.trim() !== '') {
                    const className = student.class.trim().toUpperCase();
                    if (!classScores[className]) {
                        classScores[className] = 0;
                    }
                    classScores[className] += student.totalPoints || 0;
                }
            });

            const classLeaderboard = Object.entries(classScores)
                .map(([className, totalPoints]) => ({ className, totalPoints }))
                .sort((a, b) => b.totalPoints - a.totalPoints);

            const teamsHtml = teamsArray.length === 0 ? "<p class=\"text-gray-500 col-span-full\">No teams data yet.</p>" : teamsArray.map((team, index) => {
                const medalClasses = ["text-yellow-400", "text-gray-400", "text-yellow-600", "text-blue-400"];
                const medalIcons = ["fa-crown", "fa-medal", "fa-award", "fa-star"];
                return `
                    <div class="bg-white shadow-lg rounded-xl p-6 transform hover:scale-105 transition-transform duration-300 team-card-clickable" data-team-id="${team.id}">
                        <div class="flex items-center justify-between">
                            <h2 class="text-xl font-bold text-gray-800">${team.name}</h2>
                            ${index < 4 ? `<i class="fas ${medalIcons[index]} text-2xl ${medalClasses[index]}"></i>` : ''}
                        </div>
                        <p class="text-5xl font-extrabold text-indigo-600 mt-4">${team.totalPoints}</p>
                        <p class="text-gray-500 mt-1">Total Points</p>
                    </div>`;
            }).join('');

            const toppersHtml = categoryToppers.length === 0 ? "<p class=\"text-gray-500 col-span-full\">Category toppers will be displayed here.</p>" : categoryToppers.map(topper => `
                <a href="#/student/${topper.id}" class="bg-white shadow-lg rounded-xl p-6 transform hover:scale-105 transition-transform duration-300 block">
                    <div class="flex items-center justify-between">
                        <h3 class="text-lg font-bold text-indigo-600">${topper.category} Topper</h3>
                        <i class="fas fa-star text-2xl text-yellow-400"></i>
                    </div>
                    <div class="mt-4">
                        <p class="text-2xl font-bold text-gray-800">${topper.name}</p>
                        <p class="text-sm text-gray-500">${topper.teamName}</p>
                        <p class="text-3xl font-extrabold text-indigo-500 mt-2">${topper.points} pts</p>
                    </div>
                </a>
            `).join('');

            const classLeaderboardHtml = `
                <div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-6">Best Class Award</h2>
                    <div class="bg-white shadow-lg rounded-xl overflow-hidden">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Points</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    ${classLeaderboard.length === 0 ? `<tr><td colspan="3" class="text-center py-8 text-gray-500">No class points recorded yet.</td></tr>` : classLeaderboard.slice(0, 10).map((item, index) => `
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${index + 1}</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-indigo-600">${item.className}</td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-extrabold text-gray-800">${item.totalPoints}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;

            return `
                  <div class="page space-y-12">
                      <div>
                          <h1 class="text-3xl font-bold text-gray-900 mb-6">Team Standings</h1>
                          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                              ${teamsHtml}
                          </div>
                      </div>
                      <div>
                          <h2 class="text-3xl font-bold text-gray-900 mb-6">Category-wise Scores</h2>
                          <div class="bg-white shadow-lg rounded-xl overflow-x-auto">
                             <table class="min-w-full divide-y divide-gray-200">
                                  <thead class="bg-gray-50">
                                      <tr>
                                          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
                                          ${CATEGORIES.map(cat => `<th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">${cat}</th>`).join('')}
                                      </tr>
                                  </thead>
                                  <tbody class="bg-white divide-y divide-gray-200">
                                      ${teamsArray.map(team => `
                                      <tr>
                                          <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${team.name}</td>
                                          ${CATEGORIES.map(cat => `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">${team.categoryPoints[cat] || 0}</td>`).join('')}
                                      </tr>
                                      `).join('')}
                                  </tbody>
                             </table>
                          </div>
                      </div>
                      <div>
                          <h1 class="text-3xl font-bold text-gray-900 mb-6">Category Stars</h1>
                          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                              ${toppersHtml}
                          </div>
                      </div>
                      ${classLeaderboardHtml}
                      
                  </div>`;
        }

async function renderResultsPage(_0x4edbbb = '', _stageFilter = 'All') {
            const _0x3461b0 = getDataAsArray("results").filter(_0x20f0e3 => _0x20f0e3.status === "published").sort((_0x3fbef4, _0x2adbed) => (_0x2adbed.timestamp || 0x0) - (_0x3fbef4.timestamp || 0x0));
            let _0x535a68 = _0x3461b0.filter(_0x242f5b => (_0x242f5b.programName || '').toLowerCase().includes(_0x4edbbb.toLowerCase()) || (_0x242f5b.category || '').toLowerCase().includes(_0x4edbbb.toLowerCase()));
            
            if (_stageFilter !== 'All') {
                const stageTypeFilterValue = _stageFilter === 'Stage' ? 'stage' : 'non-stage';
                _0x535a68 = _0x535a68.filter(r => (r.stageType || 'stage') === stageTypeFilterValue);
            }

            const _0x27a199 = {
                'first': {
                    'label': "1st Place",
                    'icon': 'fa-trophy',
                    'color': "text-yellow-500"
                },
                'second': {
                    'label': "2nd Place",
                    'icon': 'fa-medal',
                    'color': "text-gray-500"
                },
                'third': {
                    'label': "3rd Place",
                    'icon': 'fa-award',
                    'color': 'text-yellow-700'
                }
            };
            
            const stageFilters = ["All", "Stage", "Non-Stage"];
            
            return "\n              <div class=\"page\">\n                  <h1 class=\"text-3xl font-bold text-gray-900 mb-6\">Competition Results</h1>\n                  <div class=\"mb-6\">\n                      <form id=\"results-search-form\" class=\"flex gap-2\">\n                          <input id=\"results-search-input\" type=\"text\" placeholder=\"Search by program or category...\" value=\"" + _0x4edbbb + "\"\n                              class=\"flex-grow p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500\">\n                          <button type=\"submit\" class=\"bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors\">Search</button>\n                      </form>\n                  </div>\n                  <div id=\"results-stage-filter-container\" class=\"mb-8 flex flex-wrap gap-2\">\n                      " + stageFilters.map(stage => `\n                      <button data-stage="${stage}" class="category-filter-btn px-4 py-2 text-sm font-medium rounded-full transition-colors ${ _stageFilter === stage ? "active" : "bg-white text-gray-700"}">${stage}</button>\n                      `).join('') + "\n                  </div>\n                  <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6\">\n                      " + (_0x535a68.length === 0x0 ? "<p class=\"text-gray-500 text-center py-8 col-span-full\">No results found.</p>" : _0x535a68.map(_0x4bf2a7 => {
                const _0x29f4a7 = {
                    'first': [],
                    'second': [],
                    'third': []
                };
                const _0x590ad5 = {
                    'a_grade': [],
                    'b_grade': []
                };
                (_0x4bf2a7.participants || []).forEach(_0x45a78d => {
                    if (_0x45a78d.position && _0x29f4a7[_0x45a78d.position]) {
                        _0x29f4a7[_0x45a78d.position].push(_0x45a78d);
                    }
                    if (_0x45a78d.grade && _0x590ad5[_0x45a78d.grade]) {
                        if (!_0x45a78d.position || _0x45a78d.position === "none") {
                            _0x590ad5[_0x45a78d.grade].push(_0x45a78d);
                        }
                    }
                });
                return "\n                          <div class=\"bg-white shadow-lg rounded-xl p-6 flex flex-col\">\n                              <div class=\"border-b pb-4 mb-4 border-gray-200\">\n                                  <p class=\"text-xs font-semibold uppercase text-indigo-600\">" + _0x4bf2a7.category + " • " + (_0x4bf2a7.stageType === 'non-stage' ? 'Non-Stage' : 'Stage') + "</p>\n                                  <h2 class=\"text-xl font-bold text-gray-800 mt-1\">" + _0x4bf2a7.programName + "</h2>\n                                  <p class=\"text-sm text-gray-400 mt-2\">" + new Date(_0x4bf2a7.timestamp).toLocaleDateString() + "</p>\n                              </div>\n                              <div class=\"space-y-4 flex-grow\">\n                                  " + Object.entries(_0x29f4a7).map(([_0x34164d, _0x2b17d8]) => _0x2b17d8.length > 0x0 ? "\n                                  <div>\n                                      <h3 class=\"font-bold text-md mb-2 " + _0x27a199[_0x34164d].color + "\"><i class=\"fas " + _0x27a199[_0x34164d].icon + " mr-2\"></i>" + _0x27a199[_0x34164d].label + "</h3>\n                                      <ul class=\"space-y-1 pl-2\">\n                                      " + _0x2b17d8.map(_0x1a823a => {
                    const _0x1da8a7 = appData.students[_0x1a823a.studentId];
                    const _0x238c4c = _0x1da8a7 && appData.teams[_0x1da8a7.teamId] ? appData.teams[_0x1da8a7.teamId].name : '';
                    const displayName = _0x4bf2a7.programType === 'group' || _0x4bf2a7.programType === 'team' ? `${_0x1a823a.name} & Team` : _0x1a823a.name;
                    return "\n                                          <li class=\"text-sm\">\n                                              <a href=\"#/student/" + _0x1a823a.studentId + "\" class=\"text-gray-700 hover:text-indigo-600 hover:underline\">" + displayName + "</a>\n                                              " + (_0x238c4c ? "<span class=\"text-gray-500 text-xs ml-1\">(" + _0x238c4c + ")</span>" : '') + "\n                                              " + (_0x1a823a.grade && _0x1a823a.grade !== "none" ? "<span class=\"ml-2 text-xs font-semibold text-white bg-green-500 px-2 py-1 rounded-full\">" + _0x1a823a.grade.replace('_', " ") + "</span>" : '') + "\n                                          </li>\n                                      ";
                }).join('') + "\n                                      </ul>\n                                  </div>\n                                  " : '').join('') + "\n\n                                  " + (_0x590ad5.a_grade.length > 0x0 || _0x590ad5.b_grade.length > 0x0 ? "\n                                  <div>\n                                      <h3 class=\"font-bold text-md mb-2 text-gray-600\"><i class=\"fas fa-graduation-cap mr-2\"></i>Grade Winners</h3>\n                                      <ul class=\"space-y-1 pl-2\">\n                                          " + _0x590ad5.a_grade.map(_0x303a81 => {
                    const _0x4767c9 = appData.students[_0x303a81.studentId];
                    const _0x53de49 = _0x4767c9 && appData.teams[_0x4767c9.teamId] ? appData.teams[_0x4767c9.teamId].name : '';
                    const displayName = _0x4bf2a7.programType === 'group' || _0x4bf2a7.programType === 'team' ? `${_0x303a81.name} & Team` : _0x303a81.name;
                    return "<li class=\"text-sm\"><a href=\"#/student/" + _0x303a81.studentId + "\" class=\"text-gray-700 hover:text-indigo-600 hover:underline\">" + displayName + "</a> " + (_0x53de49 ? "<span class=\"text-gray-500 text-xs ml-1\">(" + _0x53de49 + ")</span>" : '') + " <span class=\"ml-2 text-xs font-semibold text-white bg-green-500 px-2 py-1 rounded-full\">A Grade</span></li>";
                }).join('') + "\n                                          " + _0x590ad5.b_grade.map(_0x304356 => {
                    const _0x3722c8 = appData.students[_0x304356.studentId];
                    const _0x313136 = _0x3722c8 && appData.teams[_0x3722c8.teamId] ? appData.teams[_0x3722c8.teamId].name : '';
                    const displayName = _0x4bf2a7.programType === 'group' || _0x4bf2a7.programType === 'team' ? `${_0x304356.name} & Team` : _0x304356.name;
                    return "<li class=\"text-sm\"><a href=\"#/student/" + _0x304356.studentId + "\" class=\"text-gray-700 hover:text-indigo-600 hover:underline\">" + displayName + "</a> " + (_0x313136 ? "<span class=\"text-gray-500 text-xs ml-1\">(" + _0x313136 + ')</span>' : '') + " <span class=\"ml-2 text-xs font-semibold text-white bg-blue-500 px-2 py-1 rounded-full\">B Grade</span></li>";
                }).join('') + "\n                                      </ul>\n                                  </div>\n                                  " : '') + "\n                              </div>\n                          </div>\n                          ";
            }).join('')) + "\n                  </div>\n              </div>\n            ";
        }

async function renderSearchPage() {
            return " \n              <div class=\"page max-w-lg mx-auto\">\n                  <div class=\"bg-white shadow-lg rounded-xl p-8\">\n                      <h1 class=\"text-3xl font-bold text-gray-900 mb-2\">Find Participant</h1>\n                      <p class=\"text-gray-600 mb-6\">Enter a participant's Chest Number to see their profile and results.</p>\n                      <form id=\"profile-search-form\" class=\"flex gap-2\">\n                           <input id=\"chest-no-input\" type=\"text\" placeholder=\"Enter Chest No...\" required\n                              class=\"flex-grow p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500\">\n                          <button type=\"submit\" class=\"bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors\">Search</button>\n                      </form>\n                      <p id=\"search-error\" class=\"text-red-500 text-sm mt-4 text-center\"></p>\n                  </div>\n              </div>\n            ";
        }

async function renderLeaderboardPage(_0x11f7d2 = "All") {
            const _0x285b34 = getDataAsArray('students');
            const _0x294e78 = _0x11f7d2 === "All" ? _0x285b34 : _0x285b34.filter(_0x555dd6 => _0x555dd6.category === _0x11f7d2);
            _0x294e78.sort((_0x563243, _0x200f21) => (_0x200f21.totalPoints || 0x0) - (_0x563243.totalPoints || 0x0));
            return "\n              <div class=\"page\">\n                  <h1 class=\"text-3xl font-bold text-gray-900 mb-6\">Top Scorers</h1>\n                  <div id=\"leaderboard-filter-container\" class=\"mb-6 flex flex-wrap gap-2\">\n                      <button data-category=\"All\" class=\"category-filter-btn px-4 py-2 text-sm font-medium rounded-full transition-colors " + (_0x11f7d2 === 'All' ? "active" : "bg-white text-gray-700") + "\">All</button>\n                      " + CATEGORIES.map(_0x38640e => "\n                      <button data-category=\"" + _0x38640e + "\" class=\"category-filter-btn px-4 py-2 text-sm font-medium rounded-full transition-colors " + (_0x11f7d2 === _0x38640e ? "active" : "bg-white text-gray-700") + "\">" + _0x38640e + "</button>\n                      ").join('') + "\n                  </div>\n                  <div class=\"bg-white shadow-lg rounded-xl overflow-hidden\">\n                      <div class=\"overflow-x-auto\">\n                          <table class=\"min-w-full divide-y divide-gray-200\">\n                               <thead class=\"bg-gray-50\">\n                                  <tr>\n                                      <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Rank</th>\n                                      <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Student</th>\n                                      <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Team</th>\n                                      " + (_0x11f7d2 === "All" ? "<th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Category</th>" : '') + "\n                                      <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Points</th>\n                                  </tr>\n                              </thead>\n                              <tbody class=\"bg-white divide-y divide-gray-200\">\n                                  " + _0x294e78.slice(0x0, 0x64).map((_0x1beef2, _0x1dd4f3) => "\n                                  <tr class=\"hover:bg-gray-50\">\n                                      <td class=\"px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900\">" + (_0x1dd4f3 + 0x1) + "</td>\n                                      <td class=\"px-6 py-4 whitespace-nowrap text-sm font-medium text-indigo-600\"><a href=\"#/student/" + _0x1beef2.id + "\" class=\"hover:underline\">" + _0x1beef2.name + "</a></td>\n                                      <td class=\"px-6 py-4 whitespace-nowrap text-sm text-gray-500\">" + (appData.teams[_0x1beef2.teamId]?.["name"] || 'N/A') + "</td>\n                                      " + (_0x11f7d2 === "All" ? "<td class=\"px-6 py-4 whitespace-nowrap text-sm text-gray-500\">" + _0x1beef2.category + "</td>" : '') + "\n                                      <td class=\"px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900\">" + (_0x1beef2.totalPoints || 0x0) + "</td>\n                                  </tr>\n                                  ").join('') + "\n                              </tbody>\n                          </table>\n                      </div>\n                  </div>\n              </div>\n            ";
        }

async function renderStudentPage(_0x9b64c1) {
            const _0x6d1b49 = appData.students[_0x9b64c1];
            if (!_0x6d1b49) {
                return "<p>Student not found.</p>";
            }
            const _0x3b28e0 = appData.teams[_0x6d1b49.teamId]?.['name'] || "N/A";
            const _0x42ebd8 = getDataAsArray("results").filter(_0x562d98 => _0x562d98.status === "published");
            const _0x5af6f4 = [];
            const _0x816b90 = new Set();
            const _0x597724 = {
                'first': "1st Place",
                'second': "2nd Place",
                'third': "3rd Place",
                'a_grade': "A Grade",
                'b_grade': "B Grade"
            };
            _0x42ebd8.forEach(_0x3c3b72 => {
                (_0x3c3b72.participants || []).forEach(_0x40f5ab => {
                    if (_0x40f5ab.studentId === _0x9b64c1) {
                        let _0x11bb89 = '';
                        let _0x3e460b = 0x0;
                        
                        let pointsConfigToUse;
                        if (_0x3c3b72.programType === 'group') {
                            pointsConfigToUse = appData.groupPointsConfig;
                        } else if (_0x3c3b72.programType === 'team') {
                            pointsConfigToUse = appData.teamPointsConfig;
                        } else {
                            pointsConfigToUse = appData.pointsConfig;
                        }

                        if (_0x40f5ab.position && _0x40f5ab.position !== "none") {
                            _0x11bb89 += _0x597724[_0x40f5ab.position];
                            _0x3e460b += pointsConfigToUse[_0x40f5ab.position] || 0x0;
                        }
                        if (_0x40f5ab.grade && _0x40f5ab.grade !== "none") {
                            if (_0x11bb89) {
                                _0x11bb89 += " • ";
                            }
                            _0x11bb89 += _0x597724[_0x40f5ab.grade];
                            _0x3e460b += pointsConfigToUse[_0x40f5ab.grade] || 0x0;
                        }
                        _0x5af6f4.push({
                            'programName': _0x3c3b72.programName,
                            'category': _0x3c3b72.category,
                            'prize': _0x11bb89,
                            'points': _0x3e460b,
                            'programType': _0x3c3b72.programType
                        });
                        _0x816b90.add(_0x3c3b72.programId);
                    }
                });
            });
            const _0x2f95c7 = appData.participantRegistrations || {};
            const _0x3706d6 = [];
            Object.entries(_0x2f95c7).forEach(([_0x457866, _0x38a569]) => {
                if (_0x38a569[_0x6d1b49.teamId]?.["includes"](_0x9b64c1)) {
                    if (!_0x816b90.has(_0x457866)) {
                        const _0x2800ec = appData.programs[_0x457866];
                        if (_0x2800ec) {
                            _0x3706d6.push(_0x2800ec);
                        }
                    }
                }
            });
            return "\n              <div class=\"page bg-white shadow-lg rounded-xl p-6 sm:p-8\">\n                  <div class=\"flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 mb-8 border-b pb-8 border-gray-200\">\n                      <div class=\"bg-indigo-500 text-white w-20 h-20 rounded-full flex items-center justify-center text-4xl font-bold flex-shrink-0\">\n                          " + _0x6d1b49.name.charAt(0x0) + "\n                      </div>\n                      <div class=\"text-center sm:text-left\">\n                          <h1 class=\"text-3xl sm:text-4xl font-bold text-gray-900\">" + _0x6d1b49.name + "</h1>\n                           <p class=\"text-md text-gray-500\">Chest No: " + (_0x6d1b49.chestNo || 'N/A') + "</p>\n                          <p class=\"text-lg sm:text-xl text-gray-600\">" + _0x3b28e0 + " Team • " + _0x6d1b49.category + "</p>\n                      </div>\n                      <div class=\"sm:ml-auto text-center sm:text-right pt-4 sm:pt-0\">\n                          <p class=\"text-base text-gray-500\">Total Points (Individual)</p>\n                          <p class=\"text-5xl sm:text-6xl font-extrabold text-indigo-600\">" + (_0x6d1b49.totalPoints || 0x0) + "</p>\n                      </div>\n                  </div>\n\n                  <div class=\"grid grid-cols-1 md:grid-cols-2 gap-8\">\n                      <div>\n                          <h2 class=\"text-2xl font-bold text-gray-800 mb-4\">Achievements</h2>\n                          <div class=\"space-y-4\">\n                              " + (_0x5af6f4.length === 0x0 ? "<p class=\"text-gray-500\">No achievements recorded yet.</p>" : _0x5af6f4.map(_0x527940 => {
                const programNameDisplay = _0x527940.programType === 'group' || _0x527940.programType === 'team' ? `${_0x527940.programName} (Group/Team)` : _0x527940.programName;
                return `\n                                  <div class=\"bg-gray-50 rounded-lg p-4 flex items-center justify-between\">\n                                      <div>\n                                          <p class=\"font-semibold text-lg text-gray-800\">${programNameDisplay}</p>\n                                          <p class=\"text-sm text-gray-500\">${_0x527940.category}</p>\n                                      </div>\n                                      <div class=\"text-right\">\n                                          <p class=\"font-bold text-lg text-indigo-600\">${_0x527940.prize}</p>\n                                          <p class=\"text-gray-600 font-medium\">+${_0x527940.points} Points</p>\n                                      </div>\n                                  </div>\n                                  `;
            }).join('')) + "\n                          </div>\n                      </div>\n                      <div>\n                          <h2 class=\"text-2xl font-bold text-gray-800 mb-4\">Participating In</h2>\n                           <div class=\"space-y-4\">\n                              " + (_0x3706d6.length === 0x0 ? "<p class=\"text-gray-500\">Not registered for other programs.</p>" : _0x3706d6.map(_0x5a2c54 => "\n                                  <div class=\"bg-gray-50 rounded-lg p-4\">\n                                      <p class=\"font-semibold text-lg text-gray-800\">" + _0x5a2c54.name + "</p>\n                                      <p class=\"text-sm text-gray-500\">" + _0x5a2c54.category + " • " + (_0x5a2c54.stageType === 'non-stage' ? 'Non-Stage' : 'Stage') + "</p>\n                                  </div>\n                                  ").join('')) + "\n                          </div>\n                      </div>\n                  </div>\n              </div>\n            ";
        }

async function renderNotFoundPage() {
            return "<div class=\"text-center\"><h1 class=\"text-4xl font-bold\">404 - Not Found</h1><p class=\"mt-4\">The page you are looking for does not exist.</p></div>";
        }
