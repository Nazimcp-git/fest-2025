// js/data.js
// Firebase data synchronisation and low-level data helpers.

/**
 * Opens a real-time listener on the root of the database and
 * keeps appData in sync. Triggers the router after the first load.
 */
function syncData() {
  db.ref().on('value', snapshot => {
    const raw = snapshot.val() || {};
    appData = {
      teams:                raw.teams                || {},
      students:             raw.students             || {},
      programs:             raw.programs             || {},
      results:              raw.results              || {},
      pointsConfig:         raw.pointsConfig         || { first: 5, second: 3, third: 2, a_grade: 1, b_grade: 0 },
      groupPointsConfig:    raw.groupPointsConfig    || { first: 10, second: 7, third: 5, a_grade: 0, b_grade: 0 },
      teamPointsConfig:     raw.teamPointsConfig     || { first: 15, second: 10, third: 7, a_grade: 0, b_grade: 0 },
      teamDirectScores:     raw.teamDirectScores     || {},
      teamPenalties:        raw.teamPenalties        || {},
      participantRegistrations: raw.participantRegistrations || {}
    };

    if (isInitialLoad) {
      router();
      isInitialLoad = false;
    } else {
      router(true);
    }
  }, error => {
    console.error("Firebase Read Failed:", error);
    document.getElementById("app").innerHTML =
      `<div class="p-4 text-red-500">Error connecting to the database.
       Please check your Firebase configuration and security rules.</div>`;
  });
}

/**
 * Converts an appData collection (keyed object) into an array,
 * injecting the Firebase key as the `id` property.
 * @param {string} collection  e.g. "teams", "students"
 * @returns {Array}
 */
function getDataAsArray(collection) {
  if (!appData[collection]) return [];
  return Object.entries(appData[collection]).map(([id, val]) => ({ id, ...val }));
}
