// js/admin-forms.js
// Admin form submission handlers, bulk upload, dropdowns, participant management.

async function handleAdminFormSubmit(_0x23e2e0) {
            _0x23e2e0.preventDefault();
            const _0x4df59d = _0x23e2e0.target;
            const _0xe7735e = _0x4df59d.querySelector("#form-message") || _0x4df59d.querySelector("#bulk-form-message");
            if (_0xe7735e) {
                _0xe7735e.textContent = '';
            }
            const _0x43b048 = document.querySelector('.admin-tab.active');
            const _0x568822 = _0x43b048 ? _0x43b048.dataset.tab : null;
            try {
                switch (_0x4df59d.id) {
                    case "add-team-form":
                        await db.ref("teams").push({
                            'name': _0x4df59d.querySelector('#team-name').value,
                            'createdAt': Date.now()
                        });
                        if (_0xe7735e) {
                            _0xe7735e.textContent = "Team added successfully!";
                        }
                        _0x4df59d.reset();
                        break;
                    case "add-student-form":
                        const _0x379f1 = _0x4df59d.querySelector('#student-chest-no').value;
                        const _0x111b5e = Object.values(appData.students || {}).find(_0x59c89b => _0x59c89b.chestNo === _0x379f1);
                        if (_0x111b5e) {
                            throw new Error("Chest No. " + _0x379f1 + " is already assigned to " + _0x111b5e.name + '.');
                        }
                        await db.ref("students").push({
                            'chestNo': _0x379f1,
                            'name': _0x4df59d.querySelector("#student-name").value,
                            'category': _0x4df59d.querySelector("#student-category").value,
                            'teamId': _0x4df59d.querySelector("#student-team").value,
                            'totalPoints': 0x0,
                            'createdAt': Date.now()
                        });
                        if (_0xe7735e) {
                            _0xe7735e.textContent = "Student added successfully!";
                        }
                        _0x4df59d.reset();
                        break;
                    case "add-program-form":
                        await db.ref("programs").push({
                            'name': _0x4df59d.querySelector("#program-name").value,
                            'category': _0x4df59d.querySelector("#program-category").value,
                            'stageType': _0x4df59d.querySelector('input[name="programStageType"]:checked').value,
                            'createdAt': Date.now()
                        });
                        if (_0xe7735e) {
                            _0xe7735e.textContent = "Program added successfully!";
                        }
                        _0x4df59d.reset();
                        break;
                    case "update-points-form":
                        const individualPoints = {
                            'first': parseInt(_0x4df59d.querySelector("#points-first").value),
                            'second': parseInt(_0x4df59d.querySelector("#points-second").value),
                            'third': parseInt(_0x4df59d.querySelector("#points-third").value),
                            'a_grade': parseInt(_0x4df59d.querySelector("#points-a_grade").value),
                            'b_grade': parseInt(_0x4df59d.querySelector('#points-b_grade').value)
                        };
                        const groupPoints = {
                            'first': parseInt(_0x4df59d.querySelector("#group-points-first").value),
                            'second': parseInt(_0x4df59d.querySelector("#group-points-second").value),
                            'third': parseInt(_0x4df59d.querySelector("#group-points-third").value),
                            'a_grade': parseInt(_0x4df59d.querySelector("#group-points-a_grade").value),
                            'b_grade': parseInt(_0x4df59d.querySelector('#group-points-b_grade').value)
                        };
                        const teamPoints = {
                            'first': parseInt(_0x4df59d.querySelector("#team-points-first").value),
                            'second': parseInt(_0x4df59d.querySelector("#team-points-second").value),
                            'third': parseInt(_0x4df59d.querySelector("#team-points-third").value),
                            'a_grade': parseInt(_0x4df59d.querySelector("#team-points-a_grade").value),
                            'b_grade': parseInt(_0x4df59d.querySelector('#team-points-b_grade').value)
                        };
                        await db.ref("pointsConfig").set(individualPoints);
                        await db.ref("groupPointsConfig").set(groupPoints);
                        await db.ref("teamPointsConfig").set(teamPoints);
                        await recalculateAllPoints();
                        if (_0xe7735e) {
                            _0xe7735e.textContent = "All points configurations updated and scores recalculated!";
                        }
                        break;
                    case "add-result-form":
                        const programId = _0x4df59d.querySelector('#res-program').value;
                        const programType = _0x4df59d.querySelector('input[name="programType"]:checked').value;
                        if (!programId || tempParticipants.length === 0) {
                            throw new Error("Program and at least one participant are required.");
                        }
                        const program = appData.programs[programId];
                        const participants = tempParticipants.map((p, i) => {
                            const position = document.getElementById(`pos-select-${i}`).value;
                            const grade = document.getElementById(`grade-select-${i}`).value;
                            return { ...p, position, grade };
                        });
                        const resultData = {
                            programId,
                            programName: program.name,
                            category: program.category,
                            stageType: program.stageType || 'stage',
                            programType,
                            participants,
                            status: 'pending', 
                            timestamp: Date.now()
                        };

                        if (editingResultId) {
                            await db.ref("results/" + editingResultId).set(resultData);
                            if(_0xe7735e) _0xe7735e.textContent = "Result updated successfully!";
                        } else {
                            await db.ref("results").push(resultData);
                            if(_0xe7735e) _0xe7735e.textContent = "Result uploaded for review!";
                        }
                        resetResultForm();
                        break;
                    case "bulk-upload-students-form":
                    case "bulk-upload-programs-form":
                        const _0x2b8214 = _0x4df59d.id === "bulk-upload-students-form" ? "student" : "program";
                        const _0xe175ab = _0x4df59d.querySelector("input[type=\"file\"]");
                        const _0x287e74 = _0xe175ab.files[0x0];
                        if (!_0x287e74) {
                            throw new Error("Please select a file.");
                        }
                        _0xe7735e.textContent = "Processing file...";
                        await processBulkUpload(_0x287e74, _0x2b8214, _0xe7735e);
                        _0x4df59d.reset();
                        break;
                    case "apply-penalty-form":
                        const teamId = _0x4df59d.querySelector('#penalty-team').value;
                        const points = parseInt(_0x4df59d.querySelector('#penalty-points').value, 10);
                        const reason = _0x4df59d.querySelector('#penalty-reason').value;

                        if (!teamId || !points || !reason || points <= 0) {
                            throw new Error("Please fill out all fields correctly.");
                        }

                        await db.ref("teamPenalties").push({
                            teamId,
                            points,
                            reason,
                            'createdAt': Date.now()
                        });

                        if (_0xe7735e) {
                            _0xe7735e.textContent = "Penalty applied successfully!";
                        }
                        _0x4df59d.reset();
                        break;
                }
                if (_0x568822) {
                    renderAdminTab(_0x568822);
                }
            } catch (_0x41b739) {
                console.error("Form submission error:", _0x41b739);
                if (_0xe7735e) {
                    _0xe7735e.textContent = "Error: " + _0x41b739.message;
                }
            } finally {
                setTimeout(() => {
                    const _0x311cd0 = document.querySelector('#' + _0x4df59d.id + " #form-message, #" + _0x4df59d.id + " #bulk-form-message");
                    if (_0x311cd0 && !_0x311cd0.textContent.includes("Added")) {
                        _0x311cd0.textContent = '';
                    }
                }, 0xbb8);
            }
        }

async function handleAdminFormChange(e) {
            const targetId = e.target.id;
            if (targetId === 'res-category') {
                const categoryId = e.target.value;
                populateProgramDropdown(categoryId);
                populateStudentDropdown(null);
                document.getElementById("res-program").value = ''; 
            } else if (targetId === 'res-program') {
                const categoryId = document.getElementById('res-category').value;
                const programId = e.target.value;
                if (categoryId && programId) {
                    populateStudentDropdown(categoryId);
                } else {
                    populateStudentDropdown(null);
                }
            }
        }

async function handleAdminListClick(_0x4cdbac) {
            const programItem = _0x4cdbac.target.closest(".program-item-clickable");
            if (programItem && !_0x4cdbac.target.closest('[data-no-modal-trigger]')) {
                const resultId = programItem.dataset.resultId;
                openPublishResultsModal(resultId);
                return;
            }

            const editBtn = _0x4cdbac.target.closest(".edit-result-btn");
            if (editBtn) {
                await editResult(editBtn.dataset.id);
                return;
            }

            const _0x1faf2c = _0x4cdbac.target.closest(".delete-btn");
            const _0x64603c = _0x4cdbac.target.closest(".publish-btn");
            const _0x50dd46 = _0x4cdbac.target.closest(".unpublish-btn");
            const _0x1bffa7 = _0x4cdbac.target.closest(".mark-ready-btn");
            const _0x383305 = _0x4cdbac.target.closest(".unmark-ready-btn");
            const _0x1e403c = _0x4cdbac.target.closest("#publish-all-ready-btn");
            const _0x29e13b = _0x4cdbac.target.closest(".print-btn");
            const _0x3c0f12 = _0x4cdbac.target.closest("#print-all-ready-btn");
            const _0x10c7a8 = _0x4cdbac.target.closest('#update-all-scores-btn');
            if (_0x1faf2c) {
                const {
                    id: _0xd03abc,
                    collection: _0x1dfd82
                } = _0x1faf2c.dataset;
                if (confirm("Are you sure you want to delete this item from " + _0x1dfd82 + "? This action cannot be undone.")) {
                    const _0x58f1c0 = appData[_0x1dfd82][_0xd03abc];
                    db.ref(_0x1dfd82 + '/' + _0xd03abc).remove().then(() => {
                        if (_0x1dfd82 === "results" && _0x58f1c0 && _0x58f1c0.status === "published" || _0x1dfd82 === "students" || _0x1dfd82 === "teamPenalties") {
                            recalculateAllPoints();
                        }
                    })["catch"](_0x9b922b => alert("Could not delete the item. " + _0x9b922b.message));
                }
                return;
            }
            if (_0x29e13b) {
                printResult(_0x29e13b.dataset.id);
                return;
            }
            if (_0x3c0f12) {
                printReadyResults();
                return;
            }
            if (_0x64603c) {
                db.ref("results/" + _0x64603c.dataset.id).update({
                    'status': "published"
                });
            }
            if (_0x50dd46) {
                db.ref('results/' + _0x50dd46.dataset.id).update({
                    'status': "pending"
                }).then(recalculateAllPoints);
            }
            if (_0x1bffa7) {
                db.ref("results/" + _0x1bffa7.dataset.id).update({
                    'status': "ready"
                });
            }
            if (_0x383305) {
                db.ref("results/" + _0x383305.dataset.id).update({
                    'status': "pending"
                });
            }
            if (_0x1e403c) {
                if (confirm("Are you sure you want to publish all results marked as \"Ready\"?")) {
                    const _0x3f7add = {};
                    getDataAsArray("results").forEach(_0xc01659 => {
                        if (_0xc01659.status === "ready") {
                            _0x3f7add["/results/" + _0xc01659.id + "/status"] = "published";
                        }
                    });
                    if (Object.keys(_0x3f7add).length > 0x0) {
                        db.ref().update(_0x3f7add);
                        alert(Object.keys(_0x3f7add).length + " result(s) have been published. Remember to click 'Update All Scores' to refresh the leaderboards.");
                    }
                }
            }
            if (_0x10c7a8) {
                if (confirm("Are you sure you want to update all public scores? This will recalculate points for all students and teams based on all published results.")) {
                    _0x10c7a8.disabled = true;
                    _0x10c7a8.innerHTML = "<i class=\"fas fa-spinner fa-spin mr-2\"></i>Updating...";
                    recalculateAllPoints().then(() => {
                        alert("All team and category scores have been successfully updated!");
                        _0x10c7a8.disabled = false;
                        _0x10c7a8.innerHTML = "<i class=\"fas fa-sync-alt mr-2\"></i> Update All Scores";
                    })["catch"](_0xdd1de9 => {
                        alert("An error occurred while updating scores: " + _0xdd1de9.message);
                        _0x10c7a8.disabled = false;
                        _0x10c7a8.innerHTML = "<i class=\"fas fa-sync-alt mr-2\"></i> Update All Scores";
                    });
                }
                return;
            }
        }

function processBulkUpload(_0x3c8ccf, _0x285b42, _0x30be52) {
            return new Promise((_0x1f9637, _0x11434f) => {
                const _0x55a58b = new FileReader();
                _0x55a58b.onload = async _0x40420b => {
                    try {
                        const _0x174320 = new Uint8Array(_0x40420b.target.result);
                        const _0x3791f8 = XLSX.read(_0x174320, {
                            'type': 'array'
                        });
                        const _0x493344 = _0x3791f8.SheetNames[0x0];
                        const _0x29948b = _0x3791f8.Sheets[_0x493344];
                        const _0x1ae232 = XLSX.utils.sheet_to_json(_0x29948b, {
                            'defval': ''
                        });
                        if (_0x285b42 === "student") {
                            const _0xb94e5e = getDataAsArray("students");
                            const _0x56a818 = getDataAsArray("teams");
                            const _0x3e4979 = _0x56a818.reduce((_0x5924ac, _0x3a14c8) => {
                                _0x5924ac[_0x3a14c8.name.toLowerCase().trim()] = _0x3a14c8.id;
                                return _0x5924ac;
                            }, {});
                            const _0x473d15 = {};
                            let _0xc1feaa = 0x0;
                            _0x1ae232.forEach(_0x1e4506 => {
                                const _0xa2f121 = String(_0x1e4506.ChestNo || '').trim();
                                const _0x1a2aeb = String(_0x1e4506.Name || '').trim();
                                const _0x34b1c5 = String(_0x1e4506.Category || '').trim();
                                const _0x3885cf = String(_0x1e4506.TeamName || '').trim();
                                const _0x725b61 = _0x3e4979[_0x3885cf.toLowerCase()];
                                if (_0xa2f121 && _0x1a2aeb && _0x34b1c5 && _0x725b61 && CATEGORIES.includes(_0x34b1c5) && !_0xb94e5e.some(_0x541139 => _0x541139.chestNo === _0xa2f121)) {
                                    const _0x2f5ca0 = db.ref("students").push().key;
                                    _0x473d15[_0x2f5ca0] = {
                                        'chestNo': _0xa2f121,
                                        'name': _0x1a2aeb,
                                        'category': _0x34b1c5,
                                        'teamId': _0x725b61,
                                        'totalPoints': 0x0,
                                        'createdAt': Date.now()
                                    };
                                } else {
                                    _0xc1feaa++;
                                }
                            });
                            if (Object.keys(_0x473d15).length > 0x0) {
                                await db.ref("students").update(_0x473d15);
                            }
                            _0x30be52.textContent = "Added " + Object.keys(_0x473d15).length + " students. Skipped " + _0xc1feaa + " invalid/duplicate rows.";
                        } else {
                            const _0x3fd938 = {};
                            let _0x53fc92 = 0x0;
                            _0x1ae232.forEach(_0x40c1a9 => {
                                const _0x1158b0 = String(_0x40c1a9.ProgramName || '').trim();
                                const _0x3833be = String(_0x40c1a9.Category || '').trim();
                                const _stageType = String(_0x40c1a9.StageType || 'stage').trim().toLowerCase();
                                const _validStageType = (_stageType === 'non-stage') ? 'non-stage' : 'stage';
                                if (_0x1158b0 && _0x3833be && CATEGORIES.includes(_0x3833be)) {
                                    const _0x4c1614 = db.ref("programs").push().key;
                                    _0x3fd938[_0x4c1614] = {
                                        'name': _0x1158b0,
                                        'category': _0x3833be,
                                        'stageType': _validStageType,
                                        'createdAt': Date.now()
                                    };
                                } else {
                                    _0x53fc92++;
                                }
                            });
                            if (Object.keys(_0x3fd938).length > 0x0) {
                                await db.ref("programs").update(_0x3fd938);
                            }
                            _0x30be52.textContent = "Added " + Object.keys(_0x3fd938).length + " programs. Skipped " + _0x53fc92 + " invalid rows.";
                        }
                        _0x1f9637();
                    } catch (_0x235d90) {
                        _0x11434f(_0x235d90);
                    }
                };
                _0x55a58b.onerror = () => _0x11434f(new Error("Error reading the file."));
                _0x55a58b.readAsArrayBuffer(_0x3c8ccf);
            });
        }

function downloadTemplate(_0x2b8ed9) {
            let _0x5eede2;
            let _0x36ff4f;
            if (_0x2b8ed9 === "student") {
                _0x5eede2 = [{
                    'ChestNo': "101",
                    'Name': "Amal",
                    'Category': "BIDAYA",
                    'TeamName': "Team A"
                }];
                _0x36ff4f = "student_template.xlsx";
            } else {
                _0x5eede2 = [{
                    'ProgramName': "Solo Song",
                    'Category': 'BIDAYA',
                    'StageType': 'stage'
                }];
                _0x36ff4f = "program_template.xlsx";
            }
            const _0x429eb2 = XLSX.utils.json_to_sheet(_0x5eede2);
            const _0x3069c1 = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(_0x3069c1, _0x429eb2, "Sheet1");
            XLSX.writeFile(_0x3069c1, _0x36ff4f);
        }

async function handleProfileSearch(_0x2f0789) {
            _0x2f0789.preventDefault();
            const _0x4aae98 = document.getElementById("chest-no-input");
            const _0x517c13 = document.getElementById('search-error');
            const _0x1563ae = _0x4aae98.value.trim();
            _0x517c13.textContent = '';
            if (!_0x1563ae) {
                return;
            }
            const _0x310d25 = getDataAsArray("students");
            const _0x526d1a = _0x310d25.find(_0x663de5 => _0x663de5.chestNo === _0x1563ae);
            if (_0x526d1a) {
                window.location.hash = "/student/" + _0x526d1a.id;
            } else {
                _0x517c13.textContent = "No student found with Chest No. \"" + _0x1563ae + "\".";
            }
        }

function populateProgramDropdown(categoryId) {
            const programSelect = document.getElementById("res-program");
            if (!categoryId) {
                programSelect.innerHTML = "<option>Select Category First</option>";
                programSelect.disabled = true;
            } else {
                const programs = getDataAsArray("programs").filter(p => p.category === categoryId);
                programSelect.innerHTML = "<option value=\"\">Select Program</option>" + programs.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
                programSelect.disabled = false;
            }
        }

function populateStudentDropdown(categoryId) {
            const studentSelect = document.getElementById("res-student-select");
            const addParticipantBtn = document.getElementById('add-participant-btn');
            if (categoryId) {
                const students = getDataAsArray("students").filter(s => s.category === categoryId);
                studentSelect.innerHTML = "<option value=\"\">Select Student</option>" + students.map(s => `<option value="${s.id}">${s.name} (${s.chestNo})</option>`).join('');
                studentSelect.disabled = false;
                addParticipantBtn.disabled = false;
            } else {
                studentSelect.innerHTML = "<option>Select Program First</option>";
                studentSelect.disabled = true;
                addParticipantBtn.disabled = true;
            }
        }

function addParticipantToTempList() {
            const _0x5c66d7 = document.getElementById("res-student-select");
            const _0x3346b4 = _0x5c66d7.value;
            if (!_0x3346b4) {
                return;
            }
            if (tempParticipants.some(_0x558952 => _0x558952.studentId === _0x3346b4)) {
                alert("This student is already in the list.");
                return;
            }
            const _0x54e317 = appData.students[_0x3346b4];
            tempParticipants.push({
                'studentId': _0x3346b4,
                'name': _0x54e317.name,
                'position': "none",
                'grade': "none"
            });
            renderParticipantsList();
        }

function removeParticipantFromTempList(_0x159656) {
            tempParticipants.splice(_0x159656, 0x1);
            renderParticipantsList();
        }

function renderParticipantsList() {
            const listContainer = document.getElementById('participants-list');
            if (!listContainer) return;
            listContainer.innerHTML = tempParticipants.map((participant, index) => `
              <div class="p-3 bg-gray-100 rounded-lg space-y-2">
                  <div class="flex justify-between items-center">
                      <p class="font-semibold">${participant.name}</p>
                      <button type="button" class="remove-participant-btn text-red-500 hover:text-red-700" data-index="${index}"><i class="fas fa-times-circle"></i></button>
                  </div>
                  <div class="flex gap-2">
                      <select id="pos-select-${index}" class="w-1/2 p-1 text-sm border-gray-300 rounded-md">
                          <option value="none">No Position</option>
                          <option value="first">1st Place</option>
                          <option value="second">2nd Place</option>
                          <option value="third">3rd Place</option>
                      </select>
                      <select id="grade-select-${index}" class="w-1/2 p-1 text-sm border-gray-300 rounded-md">
                          <option value="none">No Grade</option>
                          <option value="a_grade">A Grade</option>
                          <option value="b_grade">B Grade</option>
                      </select>
                  </div>
              </div>
            `).join('');
            
            tempParticipants.forEach((participant, index) => {
                document.getElementById(`pos-select-${index}`).value = participant.position || 'none';
                document.getElementById(`grade-select-${index}`).value = participant.grade || 'none';
            });
        }

function resetResultForm() {
            editingResultId = null;
            tempParticipants = [];
            const form = document.getElementById('add-result-form');
            if (form) {
                form.reset();
                const submitBtn = form.querySelector('button[type="submit"]');
                submitBtn.textContent = 'Upload for Review';
                submitBtn.classList.remove('bg-yellow-500', 'hover:bg-yellow-600');
                submitBtn.classList.add('bg-indigo-600', 'hover:bg-indigo-700');
                
                const cancelBtn = document.getElementById('cancel-edit-btn');
                if (cancelBtn) cancelBtn.remove();

                document.getElementById('res-program').disabled = true;
                document.getElementById('res-student-select').disabled = true;
                document.getElementById('add-participant-btn').disabled = true;
            }
            renderParticipantsList();
        }

async function editResult(resultId) {
            activeAdminTab = 'results';
            await renderAdminTab('results'); 

            const form = document.getElementById('add-result-form');
            if (!form) {
                console.error("Could not find the result form to edit.");
                return;
            }
            
            editingResultId = resultId;
            const result = appData.results[resultId];
            if (!result) return;

            document.getElementById('res-category').value = result.category;
            populateProgramDropdown(result.category);

            document.getElementById('res-program').value = result.programId;
            populateStudentDropdown(result.category);

            document.querySelector(`input[name="programType"][value="${result.programType || 'individual'}"]`).checked = true;

            tempParticipants = JSON.parse(JSON.stringify(result.participants || [])); 
            renderParticipantsList();
            
            const submitBtn = form.querySelector('button[type="submit"]');
            submitBtn.textContent = 'Update Result';
            submitBtn.classList.remove('bg-indigo-600', 'hover:bg-indigo-700');
            submitBtn.classList.add('bg-yellow-500', 'hover:bg-yellow-600');
            
            if (!document.getElementById('cancel-edit-btn')) {
                const cancelButton = document.createElement('button');
                cancelButton.type = 'button';
                cancelButton.id = 'cancel-edit-btn';
                cancelButton.textContent = 'Cancel Edit';
                cancelButton.className = 'w-full justify-center py-2 px-4 border shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 mt-2';
                cancelButton.onclick = resetResultForm;
                submitBtn.insertAdjacentElement('afterend', cancelButton);
            }
        }
