// js/print.js
// Print helpers — generate print-ready HTML and trigger window.print().

function printReadyResults() {
            const _0x293261 = getDataAsArray("results").filter(_0x4def7c => _0x4def7c.status === "ready").sort((_0x39436b, _0x681fef) => _0x39436b.category.localeCompare(_0x681fef.category) || _0x39436b.programName.localeCompare(_0x681fef.programName));
            if (_0x293261.length === 0x0) {
                alert("There are no results marked as \"Ready to Publish\".");
                return;
            }
            const _0x43917d = {
                'first': "1st",
                'second': "2nd",
                'third': '3rd',
                'a_grade': 'A',
                'b_grade': 'B'
            };
            const _0x4b19f2 = "\n              <div style=\"font-family: Arial, sans-serif; width: 210mm; padding: 1.5cm; box-sizing: border-box;\">\n                  <div style=\"text-align: center; border-bottom: 2px solid black; padding-bottom: 1rem; margin-bottom: 1rem;\">\n                      <h1 style=\"font-size: 22pt; margin: 0;\">Fest Results - Ready for Publication</h1>\n                      <p style=\"font-size: 12pt; margin: 0.5rem 0;\">Generated on: " + new Date().toLocaleString() + "</p>\n                  </div>\n                  " + _0x293261.map(_0x4bab42 => "\n                  <div style=\"margin-bottom: 2rem; page-break-inside: avoid;\">\n                      <h3 style=\"font-size: 14pt; margin: 0 0 0.5rem 0; font-weight: bold;\">" + _0x4bab42.programName + "</h3>\n                      <p style=\"font-size: 11pt; margin: 0 0 1rem 0; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 0.5rem;\">Category: " + _0x4bab42.category + "</p>\n                      <table style=\"width: 100%; border-collapse: collapse; font-size: 10pt;\">\n                          <thead>\n                              <tr style=\"background-color: #eee; text-align: left;\">\n                                  <th style=\"padding: 8px; border: 1px solid #ccc;\">Chest No</th>\n                                  <th style=\"padding: 8px; border: 1px solid #ccc;\">Name</th>\n                                  <th style=\"padding: 8px; border: 1px solid #ccc;\">Team</th>\n                                  <th style=\"padding: 8px; border: 1px solid #ccc;\">Position</th>\n                                  <th style=\"padding: 8px; border: 1px solid #ccc;\">Grade</th>\n                              </tr>\n                          </thead>\n                          <tbody>\n                          " + (_0x4bab42.participants || []).map(_0x57992d => {
                const _0xae8d8f = appData.students[_0x57992d.studentId];
                const _0x133b9d = _0xae8d8f && appData.teams[_0xae8d8f.teamId] ? appData.teams[_0xae8d8f.teamId].name : "N/A";
                let _0x1c2574 = _0x57992d.position && _0x57992d.position !== "none" ? _0x43917d[_0x57992d.position] : '-';
                let _0x3f1ec3 = _0x57992d.grade && _0x57992d.grade !== "none" ? _0x43917d[_0x57992d.grade] : '-';
                const displayName = _0x4bab42.programType === 'group' || _0x4bab42.programType === 'team' ? `${_0x57992d.name} & Team` : _0x57992d.name;
                return "\n                              <tr style=\"border-bottom: 1px solid #eee;\">\n                                  <td style=\"padding: 8px; border: 1px solid #ccc;\">" + _0xae8d8f.chestNo + "</td>\n                                  <td style=\"padding: 8px; border: 1px solid #ccc;\">" + displayName + "</td>\n                                  <td style=\"padding: 8px; border: 1px solid #ccc;\">" + _0x133b9d + "</td>\n                                  <td style=\"padding: 8px; border: 1px solid #ccc;\">" + _0x1c2574 + "</td>\n                                  <td style=\"padding: 8px; border: 1px solid #ccc;\">" + _0x3f1ec3 + "</td>\n                              </tr>";
            }).join('') + "\n                          </tbody>\n                      </table>\n                  </div>\n                  ").join('') + "\n              </div>\n            ";
            const _0x4a5a56 = document.getElementById("print-area");
            _0x4a5a56.innerHTML = _0x4b19f2;
            window.print();
            _0x4a5a56.innerHTML = '';
        }

function printResult(_0x423c3e) {
            const _0x597e2b = appData.results[_0x423c3e];
            if (!_0x597e2b) {
                return;
            }
            const _0x2162b3 = {
                'first': {
                    'label': "1st Place"
                },
                'second': {
                    'label': "2nd Place"
                },
                'third': {
                    'label': "3rd Place"
                }
            };
            const _0x31ea94 = ["first", "second", "third"];
            const _0x514f1b = [...(_0x597e2b.participants || [])].sort((_0xa91476, _0xe95ab1) => {
                const _0x3158b9 = _0x31ea94.indexOf(_0xa91476.position);
                const _0x15c2bb = _0x31ea94.indexOf(_0xe95ab1.position);
                if (_0x3158b9 === -0x1 && _0x15c2bb > -0x1) {
                    return 0x1;
                }
                if (_0x3158b9 > -0x1 && _0x15c2bb === -0x1) {
                    return -0x1;
                }
                if (_0x3158b9 > -0x1 && _0x15c2bb > -0x1) {
                    return _0x3158b9 - _0x15c2bb;
                }
                return 0x0;
            });
            const _0x48a952 = {
                'first': [],
                'second': [],
                'third': []
            };
            const _0x2914b8 = {
                'a_grade': [],
                'b_grade': []
            };
            _0x514f1b.forEach(_0x3bf9d4 => {
                if (_0x3bf9d4.position && _0x48a952[_0x3bf9d4.position]) {
                    _0x48a952[_0x3bf9d4.position].push(_0x3bf9d4);
                }
                if (_0x3bf9d4.grade && _0x2914b8[_0x3bf9d4.grade] && (!_0x3bf9d4.position || _0x3bf9d4.position === 'none')) {
                    _0x2914b8[_0x3bf9d4.grade].push(_0x3bf9d4);
                }
            });
            const _0x3d1129 = "\n              <div style=\"font-family: sans-serif; width: 210mm; min-height: 297mm; padding: 2cm; box-sizing: border-box;\">\n                  <div style=\"text-align: center; border-bottom: 2px solid black; padding-bottom: 1rem; margin-bottom: 2rem;\">\n                      <h1 style=\"font-size: 24pt; margin: 0;\">College Fest Results</h1>\n                      <h2 style=\"font-size: 18pt; margin: 0.5rem 0;\">" + new Date().getFullYear() + "</h2>\n                  </div>\n                  <div style=\"text-align: center; margin-bottom: 2rem;\">\n                      <h3 style=\"font-size: 16pt; margin: 0; font-weight: bold;\">" + _0x597e2b.programName + "</h3>\n                      <p style=\"font-size: 14pt; margin: 0.5rem 0; color: #555;\">Category: " + _0x597e2b.category + "</p>\n                  </div>\n                  <div style=\"font-size: 12pt;\">\n                  " + _0x31ea94.map(_0x14e9cb => {
                const _0x164c56 = _0x48a952[_0x14e9cb];
                if (!_0x164c56 || _0x164c56.length === 0x0) {
                    return '';
                }
                return "\n                      <div style=\"margin-bottom: 1.5rem;\">\n                           <h4 style=\"font-size: 14pt; border-bottom: 1px solid #ccc; padding-bottom: 0.5rem; margin-bottom: 1rem;\">" + _0x2162b3[_0x14e9cb].label + "</h4>\n                           <table style=\"width: 100%; border-collapse: collapse;\">\n                           " + _0x164c56.map(_0x3d3cf5 => {
                    const _0x8ba52e = appData.students[_0x3d3cf5.studentId];
                    const _0x159d19 = _0x8ba52e && appData.teams[_0x8ba52e.teamId] ? appData.teams[_0x8ba52e.teamId].name : 'N/A';
                    const _0xd44764 = _0x3d3cf5.grade && _0x3d3cf5.grade !== 'none' ? _0x3d3cf5.grade.replace('_', " ").toUpperCase() : '';
                    const displayName = _0x597e2b.programType === 'group' || _0x597e2b.programType === 'team' ? `${_0x3d3cf5.name} & Team` : _0x3d3cf5.name;
                    return "\n                               <tr style=\"border-bottom: 1px solid #eee;\">\n                                   <td style=\"padding: 0.5rem;\">" + _0x8ba52e.chestNo + "</td>\n                                   <td style=\"padding: 0.5rem; font-weight: bold;\">" + displayName + "</td>\n                                   <td style=\"padding: 0.5rem;\">" + _0x159d19 + "</td>\n                                   <td style=\"padding: 0.5rem; text-align: right; font-weight: bold;\">" + _0xd44764 + "</td>\n                               </tr>";
                }).join('') + "\n                           </table>\n                      </div>\n                    ";
            }).join('') + "\n                  " + (_0x2914b8.a_grade.length > 0x0 || _0x2914b8.b_grade.length > 0x0 ? "\n                      <div style=\"margin-bottom: 1.5rem;\">\n                           <h4 style=\"font-size: 14pt; border-bottom: 1px solid #ccc; padding-bottom: 0.5rem; margin-bottom: 1rem;\">Grade Winners</h4>\n                           <table style=\"width: 100%; border-collapse: collapse;\">\n                           " + [..._0x2914b8.a_grade, ..._0x2914b8.b_grade].map(_0x571ebb => {
                const _0x329ae1 = appData.students[_0x571ebb.studentId];
                const _0x23dab1 = _0x329ae1 && appData.teams[_0x329ae1.teamId] ? appData.teams[_0x329ae1.teamId].name : 'N/A';
                const _0x5a948c = _0x571ebb.grade.replace('_', " ").toUpperCase();
                const displayName = _0x597e2b.programType === 'group' || _0x597e2b.programType === 'team' ? `${_0x571ebb.name} & Team` : _0x571ebb.name;
                return "\n                               <tr style=\"border-bottom: 1px solid #eee;\">\n                                   <td style=\"padding: 0.5rem;\">" + _0x329ae1.chestNo + "</td>\n                                   <td style=\"padding: 0.5rem; font-weight: bold;\">" + displayName + "</td>\n                                   <td style=\"padding: 0.5rem;\">" + _0x23dab1 + "</td>\n                                   <td style=\"padding: 0.5rem; text-align: right; font-weight: bold;\">" + _0x5a948c + "</td>\n                               </tr>";
            }).join('') + "\n                           </table>\n                      </div>\n                    " : '') + "\n                  </div>\n                  <div style=\"position: absolute; bottom: 2cm; right: 2cm; font-size: 10pt;\">\n                      <p>Date: " + new Date().toLocaleDateString() + "</p>\n                  </div>\n              </div>\n            ";
            const _0x4e08f4 = document.getElementById('print-area');
            _0x4e08f4.innerHTML = _0x3d1129;
            window.print();
            _0x4e08f4.innerHTML = '';
        }
