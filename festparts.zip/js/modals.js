// js/modals.js
// Modal open/close helpers.

function openTeamModal(_0x737574) {
            const team = appData.teams[_0x737574];
            if (!team) { return; }

            const teamPenalties = calculateTeamPenalties();
            const directScores = appData.teamDirectScores[_0x737574] || {};
            let totalTeamPoints = 0;
            const categoryPoints = {};

            CATEGORIES.forEach(cat => {
                const points = directScores[cat] || 0;
                categoryPoints[cat] = points;
                totalTeamPoints += points;
            });

            Object.values(appData.students || {}).forEach(student => {
                if (student.teamId === _0x737574) {
                    const studentPoints = student.totalPoints || 0;
                    totalTeamPoints += studentPoints;
                    if (student.category && categoryPoints.hasOwnProperty(student.category)) {
                        categoryPoints[student.category] += studentPoints;
                    }
                }
            });

            totalTeamPoints -= (teamPenalties[_0x737574] || 0);

            const allTeams = getDataAsArray("teams").map(t => {
                let teamScore = appData.teamDirectScores[t.id] ? Object.values(appData.teamDirectScores[t.id]).reduce((a, b) => a + (b || 0), 0) : 0;
                Object.values(appData.students || {}).forEach(s => {
                    if (s.teamId === t.id) { teamScore += (s.totalPoints || 0); }
                });
                teamScore -= (teamPenalties[t.id] || 0);
                return { ...t, totalPoints: teamScore };
            }).sort((a, b) => b.totalPoints - a.totalPoints);
            
            const rank = allTeams.findIndex(t => t.id === _0x737574) + 1;

            const modalHTML = `
                <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                    <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg p-8 relative transform transition-all" style="animation: fadeIn 0.3s ease-out;">
                        <button class="close-modal-btn absolute top-4 right-4 text-gray-400 hover:text-gray-800 text-2xl">&times;</button>
                        <div class="text-center">
                            <h2 class="text-3xl font-bold text-gray-900">${team.name}</h2>
                            <p class="text-lg text-gray-500 mt-1">Rank: #${rank}</p>
                            <p class="text-7xl font-extrabold text-indigo-600 my-4">${totalTeamPoints}</p>
                        </div>
                        <div class="mt-8 border-t pt-6">
                            <h3 class="text-xl font-bold text-center mb-4">Category Points</h3>
                            <div class="space-y-2">
                                ${CATEGORIES.map(cat => `
                                    <div class="flex justify-between items-center bg-gray-50 p-3 rounded-md">
                                        <span class="font-semibold text-gray-700">${cat}</span>
                                        <span class="font-bold text-lg text-indigo-600">${categoryPoints[cat]}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            const modalContainer = document.getElementById("modal-container");
            modalContainer.innerHTML = modalHTML;
            modalContainer.classList.remove("hidden");
        }

function openPublishResultsModal(resultId) {
            const result = appData.results[resultId];
            if (!result) return;

            const positionLabels = {
                'first': "1st Place", 'second': "2nd Place", 'third': "3rd Place"
            };
            const gradeLabels = {
                'a_grade': "A Grade", 'b_grade': "B Grade"
            };

            const modalHTML = `
                <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                    <div class="bg-white rounded-xl shadow-2xl w-full max-w-2xl p-8 relative transform transition-all max-h-[90vh] flex flex-col" style="animation: fadeIn 0.3s ease-out;">
                        <button class="close-modal-btn absolute top-4 right-4 text-gray-400 hover:text-gray-800 text-2xl">&times;</button>
                        <div class="text-center mb-6">
                            <p class="text-sm font-semibold uppercase text-indigo-600">${result.category}</p>
                            <h2 class="text-3xl font-bold text-gray-900">${result.programName}</h2>
                        </div>
                        <div class="overflow-y-auto pr-4">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Chest No</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Position</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Grade</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    ${(result.participants || []).map(p => {
                                        const student = appData.students[p.studentId] || {};
                                        const team = appData.teams[student.teamId] || {};
                                        const position = p.position !== 'none' ? positionLabels[p.position] : '-';
                                        const grade = p.grade !== 'none' ? gradeLabels[p.grade] : '-';
                                        return `
                                            <tr>
                                                <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${student.chestNo || 'N/A'}</td>
                                                <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">${p.name || 'N/A'}</td>
                                                <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${team.name || 'N/A'}</td>
                                                <td class="px-4 py-3 whitespace-nowrap text-sm font-semibold text-gray-800">${position}</td>
                                                <td class="px-4 py-3 whitespace-nowrap text-sm font-semibold text-gray-800">${grade}</td>
                                            </tr>
                                        `;
                                    }).join('')}
                                    ${(result.participants || []).length === 0 ? '<tr><td colspan="5" class="text-center py-4 text-gray-500">No participants found for this result.</td></tr>' : ''}
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-6 text-center">
                            <button class="close-modal-btn bg-gray-200 text-gray-800 px-6 py-2 rounded-lg font-semibold hover:bg-gray-300">Close</button>
                        </div>
                    </div>
                </div>
            `;
            const modalContainer = document.getElementById("modal-container");
            modalContainer.innerHTML = modalHTML;
            modalContainer.classList.remove("hidden");
        }

function closeModal() {
            const modalContainer = document.getElementById("modal-container");
            modalContainer.classList.add('hidden');
            modalContainer.innerHTML = '';
        }
