// js/events.js
// Global document-level event listeners, Firebase auth observer, and app bootstrap.

// ── Global click delegation ───────────────────────────────────────────────────
document.addEventListener('click', e => {
  // Logout
  if (e.target.closest("#logout-btn")) auth.signOut();

  // Mobile hamburger menu
  const mobileMenuBtn = e.target.closest('#mobile-menu-btn');
  if (mobileMenuBtn) {
    const mobileNav = document.getElementById('mobile-nav-container');
    mobileNav.classList.toggle("open");
    if (mobileNav.classList.contains('open')) {
      mobileNav.innerHTML = `<div class="pt-2 pb-3 space-y-1">${generateNavLinks(true)}</div>`;
    }
  }

  // Team card → open modal
  const teamCard = e.target.closest('.team-card-clickable');
  if (teamCard) openTeamModal(teamCard.dataset.teamId);

  // Close modal button
  if (e.target.closest('.close-modal-btn')) closeModal();

  // Close mobile nav when any nav-link or logout is tapped
  if (e.target.closest(".nav-link") || e.target.closest("#logout-btn")) {
    document.getElementById("mobile-nav-container")?.classList.remove('open');
  }
});

// ── Login form submission ─────────────────────────────────────────────────────
document.addEventListener("submit", async e => {
  if (e.target.id === "login-form") {
    e.preventDefault();
    const email    = e.target.email.value;
    const password = e.target.password.value;
    const errorEl  = document.getElementById("login-error");
    try {
      errorEl.textContent = '';
      await auth.signInWithEmailAndPassword(email, password);
      window.location.hash = "/admin";
    } catch (err) {
      errorEl.textContent = err.message;
    }
  }
});

// ── Firebase Auth state observer ──────────────────────────────────────────────
auth.onAuthStateChanged(user => {
  const authChanged = !!currentUser !== !!user;
  currentUser = user;
  if (authChanged) {
    isInitialLoad = true;
    router();
  }
});

// ── SPA routing hooks ─────────────────────────────────────────────────────────
window.addEventListener('hashchange', () => router());

// ── Bootstrap: start data sync when DOM is ready ──────────────────────────────
window.addEventListener("DOMContentLoaded", syncData);
