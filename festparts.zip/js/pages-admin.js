// js/pages-admin.js
// Admin panel page render functions.

async function renderAdminPage() {
            if (!currentUser) {
                return "\n              <div class=\"page flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8\">\n                  <div class=\"max-w-md w-full space-y-8 bg-white p-10 rounded-xl shadow-lg\">\n                      <div><h2 class=\"mt-6 text-center text-3xl font-extrabold text-gray-900\">Admin Portal Login</h2></div>\n                      <form id=\"login-form\" class=\"mt-8 space-y-6\">\n                          <div class=\"rounded-md shadow-sm -space-y-px\">\n                              <div><input id=\"email\" name=\"email\" type=\"email\" autocomplete=\"email\" required class=\"appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm\" placeholder=\"Email address\"></div>\n                              <div><input id=\"password\" name=\"password\" type=\"password\" autocomplete=\"current-password\" required class=\"appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm\" placeholder=\"Password\"></div>\n                          </div>\n                          <div><button type=\"submit\" class=\"group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500\">Sign in</button></div>\n                          <p id=\"login-error\" class=\"text-red-500 text-sm mt-2 text-center\"></p>\n                      </form>\n                  </div>\n              </div>\n            ";
            }
            return renderAdminDashboard();
        }

async function renderAdminLoginPage() {
            return "\n              <div class=\"page flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8\">\n                  <div class=\"max-w-md w-full space-y-8 bg-white p-10 rounded-xl shadow-lg\">\n                      <div><h2 class=\"mt-6 text-center text-3xl font-extrabold text-gray-900\">Admin Portal Login</h2></div>\n                      <form id=\"login-form\" class=\"mt-8 space-y-6\">\n                          <div class=\"rounded-md shadow-sm -space-y-px\">\n                              <div><input id=\"email\" name=\"email\" type=\"email\" autocomplete=\"email\" required class=\"appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm\" placeholder=\"Email address\"></div>\n                              <div><input id=\"password\" name=\"password\" type=\"password\" autocomplete=\"current-password\" required class=\"appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm\" placeholder=\"Password\"></div>\n                          </div>\n                          <div><button type=\"submit\" class=\"group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500\">Sign in</button></div>\n                          <p id=\"login-error\" class=\"text-red-500 text-sm mt-2 text-center\"></p>\n                      </form>\n                  </div>\n              </div>\n            ";
        }

async function renderAdminDashboard() {
            setTimeout(() => renderAdminTab(activeAdminTab), 0x0);
            return "\n               <div class=\"page space-y-8\">\n                  <h1 class=\"text-3xl font-bold text-gray-900\">Admin Dashboard</h1>\n                  <div class=\"border-b border-gray-200\">\n                      <nav id=\"admin-tabs\" class=\"-mb-px flex space-x-8 overflow-x-auto\" aria-label=\"Tabs\">\n                          <button data-tab=\"dashboard\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Dashboard</button>\n                          <button data-tab=\"status\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Program Status</button>\n                          <button data-tab=\"results\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Upload Results</button>\n                          <button data-tab=\"publish\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Publish</button>\n                          <button data-tab=\"announce\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Announce Live</button>\n                          <button data-tab=\"preview\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Score Preview</button>\n                          <button data-tab=\"students\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Students</button>\n                          <button data-tab=\"teams\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Teams</button>\n                          <button data-tab=\"programs\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Programs</button>\n                           <button data-tab=\"points\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Points Config</button>\n                           <button data-tab=\"penalty\" class=\"admin-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm\">Penalty</button>\n                      </nav>\n                  </div>\n                  <div id=\"admin-tab-content\" class=\"pt-4\">\n                      <div class=\"flex justify-center items-center p-16\"><div class=\"loader\"></div></div>\n                  </div>\n              </div>\n            ";
        }

async function renderAdminTab(_0x3a4997) {
            const _0x88f17b = document.getElementById('admin-tab-content');
            if (!_0x88f17b) {
                return;
            }
            document.querySelectorAll(".admin-tab").forEach(_0xf58c86 => {
                _0xf58c86.classList.toggle("active", _0xf58c86.dataset.tab === _0x3a4997);
            });
            let _0x372c5f = '';
            const _0x41a22c = getDataAsArray("teams");
            switch (_0x3a4997) {
                 case "dashboard":
                    _0x372c5f = await renderDashboardPage();
                    break;
                case "status":
                    _0x372c5f = renderProgramStatusPage(activeStatusFilter, activeStatusCategoryFilter, activeStatusStageFilter);
                    break;
                case "results":
                    if(editingResultId) resetResultForm(); // Reset if user was editing and switched tabs
                    tempParticipants = [];
                    _0x372c5f = `
                              <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                                  <div class="lg:col-span-1 bg-white p-6 rounded-xl shadow-lg">
                                      <form id="add-result-form">
                                      <h2 class="text-2xl font-bold mb-6">Upload Result for Review</h2>
                                      <div class="space-y-4">
                                          <div>
                                              <label for="res-category" class="block text-sm font-medium text-gray-700">Category</label>
                                              <select id="res-category" name="category" required class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm">${categoryOptions()}</select>
                                          </div>
                                          <div>
                                              <label for="res-program" class="block text-sm font-medium text-gray-700">Program</label>
                                              <select id="res-program" name="program" required class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm" disabled><option>Select Category First</option></select>
                                          </div>
                                          <div>
                                              <label class="block text-sm font-medium text-gray-700">Program Type</label>
                                              <div class="mt-2 flex items-center space-x-4">
                                                  <label class="flex items-center"><input type="radio" name="programType" value="individual" class="form-radio" checked> <span class="ml-2">Individual</span></label>
                                                  <label class="flex items-center"><input type="radio" name="programType" value="group" class="form-radio"> <span class="ml-2">Group</span></label>
                                                  <label class="flex items-center"><input type="radio" name="programType" value="team" class="form-radio"> <span class="ml-2">Team</span></label>
                                              </div>
                                          </div>
                                          <hr/>
                                          <div class="bg-gray-50 p-4 rounded-lg">
                                              <h3 class="text-lg font-semibold mb-2">Add Participants</h3>
                                              <div class="flex items-center gap-2">
                                                  <select id="res-student-select" class="flex-grow block w-full p-2 border-gray-300 rounded-md shadow-sm" disabled><option>Select Program First</option></select>
                                                  <button type="button" id="add-participant-btn" class="bg-green-500 text-white px-3 py-2 rounded-md font-semibold text-sm hover:bg-green-600" disabled>+</button>
                                              </div>
                                          </div>
                                          <div id="participants-list" class="space-y-2"></div>
                                          <button type="submit" class="w-full justify-center py-2 px-6 border shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">Upload for Review</button>
                                          <p id="form-message" class="text-sm mt-2 text-center"></p>
                                      </div>
                                      </form>
                                  </div>
                                   <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg">
                                      <h2 class="text-2xl font-bold mb-6">Uploaded Results</h2>
                                      <div id="recent-results-list" class="space-y-4 max-h-[80vh] overflow-y-auto pr-2"></div>
                                  </div>
                              </div>
                            `;
                    break;
                case "publish":
                    const _0x578940 = getDataAsArray("results").sort((_0x3030fa, _0x2496ca) => _0x2496ca.timestamp - _0x3030fa.timestamp);
                    _0x372c5f = `
                        <div class="bg-white p-6 rounded-xl shadow-lg">
                            <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                                <h2 class="text-2xl font-bold">Manage Results Publication</h2>
                                <div class="w-full md:w-1/3">
                                    <input type="text" id="publish-search-input" placeholder="Search programs..." class="w-full p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                                </div>
                                <div class="flex gap-2 flex-wrap justify-center">
                                    <button id="print-all-ready-btn" class="bg-gray-600 text-white px-4 py-2 text-sm font-semibold rounded-md hover:bg-gray-700"><i class="fas fa-print mr-2"></i>Print All Ready</button>
                                    <button id="publish-all-ready-btn" class="bg-blue-600 text-white px-4 py-2 text-sm font-semibold rounded-md hover:bg-blue-700">Publish All Ready</button>
                                    <button id="update-all-scores-btn" class="bg-red-600 text-white px-4 py-2 text-sm font-semibold rounded-md hover:bg-red-700"><i class="fas fa-sync-alt mr-2"></i>Update All Scores</button>
                                </div>
                            </div>
                            <div id="publish-list" class="space-y-6 pr-2 max-h-[70vh] overflow-y-auto">
                            ${(_0x578940.length === 0x0 ? "<p class=\"text-gray-500 text-center py-4\">No results have been uploaded yet.</p>" : _0x578940.map(_0x23e4de => {
                                const _0x47f43c = {};
                                const pointsConfigForImpact = _0x23e4de.programType === 'group' ? appData.groupPointsConfig : _0x23e4de.programType === 'team' ? appData.teamPointsConfig : appData.pointsConfig;

                                (_0x23e4de.participants || []).forEach(_0x3880e9 => {
                                    const _0xf3b299 = appData.students[_0x3880e9.studentId];
                                    if (!_0xf3b299 || !_0xf3b299.teamId) return;
                                    const _0x1ceabb = _0xf3b299.teamId;
                                    if (!_0x47f43c[_0x1ceabb]) {
                                        _0x47f43c[_0x1ceabb] = { 'points': 0x0, 'teamName': appData.teams[_0x1ceabb]?.['name'] || "Unknown" };
                                    }
                                    let _0x22d001 = 0x0;
                                    if (_0x3880e9.position && _0x3880e9.position !== "none") _0x22d001 += pointsConfigForImpact[_0x3880e9.position] || 0x0;
                                    if (_0x3880e9.grade && _0x3880e9.grade !== "none") _0x22d001 += pointsConfigForImpact[_0x3880e9.grade] || 0x0;
                                    _0x47f43c[_0x1ceabb].points += _0x22d001;
                                });
                                const _0x2ed5f9 = Object.values(_0x47f43c).sort((_0xb12717, _0x3fff28) => _0x3fff28.points - _0xb12717.points);
                                let _0x10ff74, _0x41020c;
                                switch (_0x23e4de.status) {
                                    case "published":
                                        _0x10ff74 = `<span class="text-xs font-semibold text-white bg-green-500 px-2 py-1 rounded-full">Published</span>`;
                                        _0x41020c = `<button class="unpublish-btn bg-yellow-500 text-white px-3 py-1 text-sm font-semibold rounded-md hover:bg-yellow-600" data-id="${_0x23e4de.id}">Unpublish</button>
                                                    <button class="print-btn bg-gray-500 text-white px-3 py-1 text-sm font-semibold rounded-md hover:bg-gray-600" data-id="${_0x23e4de.id}"><i class="fas fa-print"></i></button>`;
                                        break;
                                    case "ready":
                                        _0x10ff74 = `<span class="text-xs font-semibold text-white bg-blue-500 px-2 py-1 rounded-full">Ready to Publish</span>`;
                                        _0x41020c = `<button class="unmark-ready-btn bg-gray-400 text-white px-3 py-1 text-sm font-semibold rounded-md hover:bg-gray-500" data-id="${_0x23e4de.id}">Unmark</button>
                                                    <button class="publish-btn bg-green-500 text-white px-3 py-1 text-sm font-semibold rounded-md hover:bg-green-600" data-id="${_0x23e4de.id}">Publish</button>`;
                                        break;
                                    default:
                                        _0x10ff74 = `<span class="text-xs font-semibold text-white bg-gray-500 px-2 py-1 rounded-full">Pending</span>`;
                                        _0x41020c = `<button class="mark-ready-btn bg-blue-500 text-white px-3 py-1 text-sm font-semibold rounded-md hover:bg-blue-600" data-id="${_0x23e4de.id}">Mark as Ready</button>`;
                                }
                                return `
                                    <div class="border rounded-lg p-4 program-item-container ${(_0x23e4de.status === "published" ? "bg-green-50" : _0x23e4de.status === "ready" ? "bg-blue-50" : "bg-gray-50")}" data-program-name="${_0x23e4de.programName.toLowerCase()}">
                                        <div class="flex justify-between items-start mb-4">
                                            <div class="program-item-clickable cursor-pointer flex-grow" data-result-id="${_0x23e4de.id}">
                                                <div class="flex items-center gap-2 mb-1">
                                                    <p class="font-bold text-lg text-gray-800">${_0x23e4de.programName}</p>
                                                    ${_0x10ff74}
                                                </div>
                                                <p class="text-sm text-gray-500">${_0x23e4de.category} • ${_0x23e4de.stageType === 'non-stage' ? 'Non-Stage' : 'Stage'}</p>
                                            </div>
                                            <div class="flex items-center gap-2 flex-shrink-0" data-no-modal-trigger="true">
                                                ${_0x41020c}
                                                <button class="delete-btn text-red-500 hover:text-red-700" data-id="${_0x23e4de.id}" data-collection="results"><i class="fas fa-trash"></i></button>
                                            </div>
                                        </div>
                                        <div class="program-item-clickable cursor-pointer" data-result-id="${_0x23e4de.id}">
                                            <h4 class="font-semibold text-sm mb-2">Team Point Impact:</h4>
                                            <div class="flex flex-wrap gap-x-4 gap-y-1">
                                                ${_0x2ed5f9.map(_0x1631b3 => `
                                                <span class="text-sm text-gray-700"><strong>${_0x1631b3.teamName}:</strong> <span class="font-bold text-green-600">+${_0x1631b3.points}</span></span>
                                                `).join('')}
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }).join(''))}
                            </div>
                        </div>
                    `;
                    break;
                case 'announce':
                    _0x372c5f = renderAnnounceLivePage();
                    break;
                case "preview":
                    _0x372c5f = renderScorePreviewPage();
                    break;
                case "students":
                    _0x372c5f = "\n                              <div class=\"grid grid-cols-1 lg:grid-cols-3 gap-8\">\n                                  <div class=\"lg:col-span-2 bg-white p-6 rounded-xl shadow-lg order-2 lg:order-1\">\n                                      <h2 class=\"text-2xl font-bold mb-6\">All Students</h2>\n                                      <div id=\"items-list\" class=\"space-y-2 max-h-[80vh] overflow-y-auto pr-2\"></div>\n                                  </div>\n                                  <div class=\"lg:col-span-1 bg-white p-6 rounded-xl shadow-lg order-1 lg:order-2 space-y-8\">\n                                      <div>\n                                          <h2 class=\"text-2xl font-bold mb-6\">Add New Student</h2>\n                                          <form id=\"add-student-form\" class=\"space-y-4\">\n                                              <div><label for=\"student-chest-no\" class=\"block text-sm font-medium\">Chest No.</label><input type=\"text\" id=\"student-chest-no\" required class=\"mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm\"></div>\n                                              <div><label for=\"student-name\" class=\"block text-sm font-medium\">Student Name</label><input type=\"text\" id=\"student-name\" required class=\"mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm\"></div>\n                                              <div><label for=\"student-category\" class=\"block text-sm font-medium\">Category</label><select id=\"student-category\" required class=\"mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm\">" + categoryOptions() + "</select></div>\n                                              <div><label for=\"student-team\" class=\"block text-sm font-medium\">Team</label><select id=\"student-team\" required class=\"mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm\"><option value=\"\">Select Team</option>" + _0x41a22c.map(_0x1b1c4b => "<option value=\"" + _0x1b1c4b.id + "\">" + _0x1b1c4b.name + '</option>').join('') + "</select></div>\n                                              <button type=\"submit\" class=\"w-full justify-center py-2 px-4 border shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700\">Add Student</button>\n                                              <p id=\"form-message\" class=\"text-sm mt-2 text-center\"></p>\n                                          </form>\n                                      </div>\n                                      <hr/>\n                                      <div>\n                                          <h2 class=\"text-2xl font-bold mb-6\">Bulk Upload Students</h2>\n                                          <form id=\"bulk-upload-students-form\" class=\"space-y-4\">\n                                              <div class=\"text-sm\">\n                                                  <p class=\"mb-2\">Upload an Excel (.xlsx) file with columns:</p>\n                                                  <code class=\"text-xs bg-gray-200 p-1 rounded\">ChestNo, Name, Category, TeamName</code>\n                                              </div>\n                                              <div>\n                                                  <input type=\"file\" id=\"student-file-input\" class=\"block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100\" accept=\".xlsx\" required>\n                                              </div>\n                                              <button type=\"submit\" class=\"w-full justify-center py-2 px-4 border shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700\">Upload File</button>\n                                              <button type=\"button\" id=\"download-student-template\" class=\"w-full text-center py-2 px-4 border text-sm font-medium rounded-md text-indigo-600 bg-indigo-50 hover:bg-indigo-100\">Download Template</button>\n                                              <p id=\"bulk-form-message\" class=\"text-sm mt-2 text-center\"></p>\n                                          </form>\n                                      </div>\n                                  </div>\n                              </div>";
                    break;
                case "teams":
                    _0x372c5f = "\n                              <div class=\"grid grid-cols-1 lg:grid-cols-3 gap-8\">\n                                  <div class=\"lg:col-span-1 bg-white p-6 rounded-xl shadow-lg\">\n                                      <h2 class=\"text-2xl font-bold mb-6\">Add New Team</h2>\n                                      <form id=\"add-team-form\" class=\"space-y-4\">\n                                          <div><label for=\"team-name\" class=\"block text-sm font-medium\">Team Name</label><input type=\"text\" id=\"team-name\" required class=\"mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm\"></div>\n                                          <button type=\"submit\" class=\"w-full justify-center py-2 px-4 border shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700\">Add Team</button>\n                                          <p id=\"form-message\" class=\"text-sm mt-2 text-center\"></p>\n                                      </form>\n                                  </div>\n                                  <div class=\"lg:col-span-2 bg-white p-6 rounded-xl shadow-lg\"><h2 class=\"text-2xl font-bold mb-6\">All Teams</h2><div id=\"items-list\" class=\"space-y-2 max-h-[80vh] overflow-y-auto pr-2\"></div></div>\n                              </div>";
                    break;
                case "programs":
                    _0x372c5f = "\n                              <div class=\"grid grid-cols-1 lg:grid-cols-3 gap-8\">\n                                   <div class=\"lg:col-span-2 bg-white p-6 rounded-xl shadow-lg order-2 lg:order-1\">\n                                      <h2 class=\"text-2xl font-bold mb-6\">All Programs</h2>\n                                      <div id=\"items-list\" class=\"space-y-2 max-h-[80vh] overflow-y-auto pr-2\"></div>\n                                  </div>\n                                  <div class=\"lg:col-span-1 bg-white p-6 rounded-xl shadow-lg order-1 lg:order-2 space-y-8\">\n                                      <div>\n                                          <h2 class=\"text-2xl font-bold mb-6\">Add New Program</h2>\n                                          <form id=\"add-program-form\" class=\"space-y-4\">\n                                              <div><label for=\"program-name\" class=\"block text-sm font-medium\">Program Name</label><input type=\"text\" id=\"program-name\" required class=\"mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm\"></div>\n                                              <div><label for=\"program-category\" class=\"block text-sm font-medium\">Category</label><select id=\"program-category\" required class=\"mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm\">" + categoryOptions() + "</select></div>\n                                              <div><label class=\"block text-sm font-medium text-gray-700\">Stage Type</label><div class=\"mt-2 flex items-center space-x-4\"><label class=\"flex items-center\"><input type=\"radio\" name=\"programStageType\" value=\"stage\" class=\"form-radio\" checked> <span class=\"ml-2\">Stage</span></label><label class=\"flex items-center\"><input type=\"radio\" name=\"programStageType\" value=\"non-stage\" class=\"form-radio\"> <span class=\"ml-2\">Non-Stage</span></label></div></div>\n                                              <button type=\"submit\" class=\"w-full justify-center py-2 px-4 border shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700\">Add Program</button>\n                                              <p id=\"form-message\" class=\"text-sm mt-2 text-center\"></p>\n                                          </form>\n                                      </div>\n                                      <hr/>\n                                      <div>\n                                          <h2 class=\"text-2xl font-bold mb-6\">Bulk Upload Programs</h2>\n                                          <form id=\"bulk-upload-programs-form\" class=\"space-y-4\">\n                                              <div class=\"text-sm\">\n                                                  <p class=\"mb-2\">Upload an Excel (.xlsx) file with columns:</p>\n                                                  <code class=\"text-xs bg-gray-200 p-1 rounded\">ProgramName, Category, StageType</code>\n                                              </div>\n                                              <div>\n                                                  <input type=\"file\" id=\"program-file-input\" class=\"block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100\" accept=\".xlsx\" required>\n                                              </div>\n                                              <button type=\"submit\" class=\"w-full justify-center py-2 px-4 border shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700\">Upload File</button>\n                                              <button type=\"button\" id=\"download-program-template\" class=\"w-full text-center py-2 px-4 border text-sm font-medium rounded-md text-indigo-600 bg-indigo-50 hover:bg-indigo-100\">Download Template</button>\n                                              <p id=\"bulk-form-message\" class=\"text-sm mt-2 text-center\"></p>\n                                          </form>\n                                      </div>\n                                  </div>\n                              </div>";
                    break;
                case 'points':
                    _0x372c5f = `
                              <div class="max-w-4xl mx-auto">
                                  <form id="update-points-form" class="space-y-8">
                                      <div class="bg-white p-6 rounded-xl shadow-lg">
                                          <h2 class="text-2xl font-bold mb-6">Individual Program Points</h2>
                                          <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                              <div><label for="points-first" class="block text-sm font-medium">1st Place</label><input type="number" id="points-first" value="${appData.pointsConfig.first}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="points-second" class="block text-sm font-medium">2nd Place</label><input type="number" id="points-second" value="${appData.pointsConfig.second}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="points-third" class="block text-sm font-medium">3rd Place</label><input type="number" id="points-third" value="${appData.pointsConfig.third}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="points-a_grade" class="block text-sm font-medium">A Grade</label><input type="number" id="points-a_grade" value="${appData.pointsConfig.a_grade}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="points-b_grade" class="block text-sm font-medium">B Grade</label><input type="number" id="points-b_grade" value="${appData.pointsConfig.b_grade}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                          </div>
                                      </div>
                                      <div class="bg-white p-6 rounded-xl shadow-lg">
                                          <h2 class="text-2xl font-bold mb-6">Group Program Points</h2>
                                          <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                              <div><label for="group-points-first" class="block text-sm font-medium">1st Place</label><input type="number" id="group-points-first" value="${appData.groupPointsConfig.first}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="group-points-second" class="block text-sm font-medium">2nd Place</label><input type="number" id="group-points-second" value="${appData.groupPointsConfig.second}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="group-points-third" class="block text-sm font-medium">3rd Place</label><input type="number" id="group-points-third" value="${appData.groupPointsConfig.third}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="group-points-a_grade" class="block text-sm font-medium">A Grade</label><input type="number" id="group-points-a_grade" value="${appData.groupPointsConfig.a_grade}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="group-points-b_grade" class="block text-sm font-medium">B Grade</label><input type="number" id="group-points-b_grade" value="${appData.groupPointsConfig.b_grade}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                          </div>
                                      </div>
                                      <div class="bg-white p-6 rounded-xl shadow-lg">
                                          <h2 class="text-2xl font-bold mb-6">Team Program Points</h2>
                                          <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                              <div><label for="team-points-first" class="block text-sm font-medium">1st Place</label><input type="number" id="team-points-first" value="${appData.teamPointsConfig.first}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="team-points-second" class="block text-sm font-medium">2nd Place</label><input type="number" id="team-points-second" value="${appData.teamPointsConfig.second}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="team-points-third" class="block text-sm font-medium">3rd Place</label><input type="number" id="team-points-third" value="${appData.teamPointsConfig.third}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="team-points-a_grade" class="block text-sm font-medium">A Grade</label><input type="number" id="team-points-a_grade" value="${appData.teamPointsConfig.a_grade}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                              <div><label for="team-points-b_grade" class="block text-sm font-medium">B Grade</label><input type="number" id="team-points-b_grade" value="${appData.teamPointsConfig.b_grade}" required class="mt-1 w-full p-2 border-gray-300 rounded-md"></div>
                                          </div>
                                      </div>
                                      <button type="submit" class="w-full justify-center py-3 px-6 border shadow-sm text-md font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">Save All Changes</button>
                                      <p id="form-message" class="text-sm mt-2 text-center"></p>
                                  </form>
                              </div>
                            `;
                    break;
                case 'penalty':
                    const teamsArrayForPenalty = getDataAsArray("teams");
                    _0x372c5f = `
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <div class="lg:col-span-1 bg-white p-6 rounded-xl shadow-lg">
                                <h2 class="text-2xl font-bold mb-6">Apply Penalty</h2>
                                <form id="apply-penalty-form" class="space-y-4">
                                    <div>
                                        <label for="penalty-team" class="block text-sm font-medium">Team</label>
                                        <select id="penalty-team" required class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm">
                                            <option value="">Select Team</option>
                                            ${teamsArrayForPenalty.map(team => `<option value="${team.id}">${team.name}</option>`).join('')}
                                        </select>
                                    </div>
                                    <div>
                                        <label for="penalty-points" class="block text-sm font-medium">Penalty Points (e.g., 10)</label>
                                        <input type="number" id="penalty-points" min="1" required class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm">
                                    </div>
                                    <div>
                                        <label for="penalty-reason" class="block text-sm font-medium">Reason</label>
                                        <input type="text" id="penalty-reason" required class="mt-1 block w-full p-2 border-gray-300 rounded-md shadow-sm">
                                    </div>
                                    <button type="submit" class="w-full justify-center py-2 px-4 border shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700">Apply Penalty</button>
                                    <p id="form-message" class="text-sm mt-2 text-center"></p>
                                </form>
                            </div>
                            <div class="lg:col-span-2 bg-white p-6 rounded-xl shadow-lg">
                                <h2 class="text-2xl font-bold mb-6">Applied Penalties</h2>
                                <div id="items-list" class="space-y-2 max-h-[80vh] overflow-y-auto pr-2"></div>
                            </div>
                        </div>
                    `;
                    break;
            }
            _0x88f17b.innerHTML = _0x372c5f;
            if (_0x3a4997 === "results") {
                loadRecentResults();
            }
            if (['students', 'teams', "programs", "penalty"].includes(_0x3a4997)) {
                loadItemsList(_0x3a4997);
            }
        }

async function renderDashboardPage() {
            const { teamsArray, studentsArray } = calculateAllScoresInternal();

            const teamsHtml = teamsArray.length === 0 ? "<p class=\"text-gray-500 col-span-full\">No teams data yet.</p>" : teamsArray.map((team, index) => {
                const medalClasses = ["text-yellow-400", "text-gray-400", "text-yellow-600", "text-blue-400"];
                const medalIcons = ["fa-crown", "fa-medal", "fa-award", "fa-star"];
                return `
                    <div class="bg-white shadow-lg rounded-xl p-6">
                        <div class="flex items-center justify-between">
                            <h2 class="text-xl font-bold text-gray-800">${team.name}</h2>
                            ${index < 4 ? `<i class="fas ${medalIcons[index]} text-2xl ${medalClasses[index]}"></i>` : ''}
                        </div>
                        <p class="text-5xl font-extrabold text-indigo-600 mt-4">${team.totalPoints}</p>
                        <p class="text-gray-500 mt-1">Total Points</p>
                    </div>`;
            }).join('');

            const studentsHtml = studentsArray.length === 0 ? `<tr><td colspan="5" class="text-center py-8 text-gray-500">No student data yet.</td></tr>` : studentsArray.slice(0, 50).map((student, index) => `
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${index + 1}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-indigo-600"><a href="#/student/${student.id}" class="hover:underline">${student.name}</a></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${appData.teams[student.teamId]?.name || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${student.category}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">${student.totalPoints || 0}</td>
                </tr>
            `).join('');

            return `
                <div class="page space-y-12">
                    <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md" role="alert">
                        <p class="font-bold">Internal Dashboard</p>
                        <p>This is a live view of all scores, including pending, ready, and published results. This is NOT the public score.</p>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900 mb-6">Live Team Standings (All Results)</h1>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            ${teamsHtml}
                        </div>
                    </div>
                    <div>
                        <h2 class="text-3xl font-bold text-gray-900 mb-6">Live Student Leaderboard (Top 50)</h2>
                        <div class="bg-white shadow-lg rounded-xl overflow-hidden">
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Points</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        ${studentsHtml}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

function renderProgramStatusPage(statusFilter = 'All', categoryFilter = 'All', stageFilter = 'All') {
            const programs = getDataAsArray("programs").sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
            const results = getDataAsArray("results");
            
            let programStatuses = programs.map(program => {
                const result = results.find(r => r.programId === program.id);
                let status = "Not Entered";
                if (result) {
                    if (result.status === "published") status = "Published";
                    else if (result.status === "ready") status = "Ready to Publish";
                    else status = "Pending";
                }
                return { ...program, status };
            });

            if (statusFilter !== "All") {
                programStatuses = programStatuses.filter(p => p.status === statusFilter);
            }
            if (categoryFilter !== "All") {
                programStatuses = programStatuses.filter(p => p.category === categoryFilter);
            }
            if (stageFilter !== "All") {
                const stageTypeFilterValue = stageFilter === 'Stage' ? 'stage' : 'non-stage';
                programStatuses = programStatuses.filter(p => (p.stageType || 'stage') === stageTypeFilterValue);
            }

            const getStatusBadge = (status) => {
                switch (status) {
                    case "Published": return `<span class="text-xs font-semibold text-white bg-green-500 px-2 py-1 rounded-full">${status}</span>`;
                    case "Ready to Publish": return `<span class="text-xs font-semibold text-white bg-blue-500 px-2 py-1 rounded-full">${status}</span>`;
                    case "Pending": return `<span class="text-xs font-semibold text-white bg-gray-500 px-2 py-1 rounded-full">${status}</span>`;
                    default: return `<span class="text-xs font-semibold text-white bg-red-500 px-2 py-1 rounded-full">${status}</span>`;
                }
            };
            
            const statusFilters = ["All", 'Published', "Ready to Publish", "Pending", "Not Entered"];
            const stageFilters = ["All", "Stage", "Non-Stage"];
            
            return `
              <div class="page">
                  <h1 class="text-3xl font-bold text-gray-900 mb-6">Program Status Overview</h1>
                  <div id="category-filter-container" class="mb-4 flex flex-wrap gap-2">
                      <button data-category="All" class="category-filter-btn px-4 py-2 text-sm font-medium rounded-full transition-colors ${categoryFilter === 'All' ? 'active' : 'bg-white text-gray-700'}">All Categories</button>
                      ${CATEGORIES.map(cat => `
                          <button data-category="${cat}" class="category-filter-btn px-4 py-2 text-sm font-medium rounded-full transition-colors ${categoryFilter === cat ? 'active' : 'bg-white text-gray-700'}">${cat}</button>
                      `).join('')}
                  </div>
                  <div id="status-filter-container" class="mb-4 flex flex-wrap gap-2">
                      ${statusFilters.map(status => `
                      <button data-status="${status}" class="category-filter-btn px-4 py-2 text-sm font-medium rounded-full transition-colors ${statusFilter === status ? "active" : "bg-white text-gray-700"}">${status}</button>
                      `).join('')}
                  </div>
                  <div id="stage-filter-container" class="mb-6 flex flex-wrap gap-2">
                      ${stageFilters.map(stage => `
                      <button data-stage="${stage}" class="category-filter-btn px-4 py-2 text-sm font-medium rounded-full transition-colors ${stageFilter === stage ? "active" : "bg-white text-gray-700"}">${stage}</button>
                      `).join('')}
                  </div>

                  <div class="bg-white shadow-lg rounded-xl overflow-hidden">
                      <div id="items-list" class="overflow-x-auto max-h-[70vh] overflow-y-auto pr-2">
                          <table class="min-w-full divide-y divide-gray-200">
                               <thead class="bg-gray-50">
                                  <tr>
                                      <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Program Name</th>
                                      <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                      <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                      <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                  </tr>
                              </thead>
                              <tbody class="bg-white divide-y divide-gray-200">
                                  ${(programStatuses.length === 0 ? "<tr><td colspan=\"4\" class=\"text-center py-8 text-gray-500\">No programs match this filter.</td></tr>" : programStatuses.map(p => `
                                  <tr class="hover:bg-gray-50">
                                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${p.name}</td>
                                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${p.category}</td>
                                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${p.stageType === 'non-stage' ? 'Non-Stage' : 'Stage'}</td>
                                      <td class="px-6 py-4 whitespace-nowrap text-sm">${getStatusBadge(p.status)}</td>
                                  </tr>
                                  `).join(''))}
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
            `;
        }

function renderAnnounceLivePage() {
            const readyResults = getDataAsArray("results").filter(result => result.status === "ready").sort((a, b) => {
                const categoryAIndex = CATEGORIES.indexOf(a.category);
                const categoryBIndex = CATEGORIES.indexOf(b.category);
                if (categoryAIndex !== categoryBIndex) {
                    return categoryAIndex - categoryBIndex;
                }
                return a.programName.localeCompare(b.programName);
            });
            
            const positionLabels = {
                'first': "1st Place", 'second': "2nd Place", 'third': "3rd Place",
                'a_grade': "A Grade", 'b_grade': "B Grade"
            };

            const groupedResults = readyResults.reduce((acc, result) => {
                const category = result.category;
                if (!acc[category]) {
                    acc[category] = [];
                }
                acc[category].push(result);
                return acc;
            }, {});

            const pageHTML = `
              <div class="page space-y-8">
                   <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md flex flex-col md:flex-row justify-between items-center gap-4" role="alert">
                        <div>
                            <p class="font-bold">Live Announce Mode</p>
                            <p>"Publish Now" makes a result public. Click "Update All Scores" to refresh the main leaderboards.</p>
                        </div>
                        <button id="update-all-scores-btn" class="bg-red-600 text-white px-6 py-3 text-md font-bold rounded-lg hover:bg-red-700 transition-transform transform hover:scale-105 flex-shrink-0">
                            <i class="fas fa-sync-alt mr-2"></i> Update All Scores
                        </button>
                   </div>
                   <div id="announce-list" class="pr-2">
                       ${Object.keys(groupedResults).length === 0 
                           ? `<p class="text-gray-500 text-center py-8 text-xl">No results are currently ready for announcement.</p>`
                           : CATEGORIES.map(category => {
                               if (!groupedResults[category]) return '';
                               const resultsInCategory = groupedResults[category];
                               return `
                                   <div class="mb-12">
                                       <h2 class="text-3xl font-extrabold text-gray-800 border-b-4 border-indigo-300 pb-3 mb-6">${category}</h2>
                                       <div class="space-y-6">
                                       ${resultsInCategory.map(result => {
                                           return `
                                               <div class="bg-white shadow-2xl rounded-xl p-8 border-t-4 border-indigo-500">
                                                   <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                                                       <div class="text-center md:text-left">
                                                          
                                                           <h2 class="text-4xl font-bold text-gray-900">${result.programName}</h2>
                                                           <p class="text-lg text-gray-500 mt-2">${result.category} • ${result.stageType === 'non-stage' ? 'Non-Stage' : 'Stage'}</p>
                                                       </div>
                                                       <button class="publish-btn w-full md:w-auto bg-green-600 text-white px-10 py-4 text-xl font-bold rounded-lg hover:bg-green-700 transition-transform transform hover:scale-105" data-id="${result.id}">
                                                           <i class="fas fa-bullhorn mr-2"></i> Publish Now
                                                       </button>
                                                   </div>
                                                   <div class="mt-6 border-t pt-6">
                                                       <h3 class="text-2xl font-bold mb-4 text-gray-800">Winners List</h3>
                                                       <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-lg">
                                                           ${(result.participants || []).map(participant => {
                                                               const student = appData.students[participant.studentId];
                                                               const teamName = student && appData.teams[student.teamId] ? appData.teams[student.teamId].name : 'N/A';
                                                               let prize = '';
                                                               if (participant.position && participant.position !== 'none') {
                                                                   prize += positionLabels[participant.position];
                                                               }
                                                               if (participant.grade && participant.grade !== "none") {
                                                                   if (prize) prize += " • ";
                                                                   prize += positionLabels[participant.grade];
                                                               }
                                                               const displayName = result.programType === 'group' || result.programType === 'team' ? `${participant.name} & Team` : participant.name;
                                                               return `
                                                                   <div class="bg-gray-50 p-3 rounded-md">
                                                                       <p class="font-bold text-gray-900">${displayName} <span class="text-gray-500 font-medium">(${student.chestNo})</span></p>
                                                                       <p class="text-indigo-700 font-semibold">${prize}</p>
                                                                       <p class="text-sm text-gray-600">${teamName}</p>
                                                                   </div>
                                                               `;
                                                           }).join('')}
                                                       </div>
                                                   </div>
                                               </div>
                                           `;
                                       }).join('')}
                                       </div>
                                   </div>
                               `;
                           }).join('')}
                   </div>
              </div>
            `;
            return pageHTML;
        }

function renderScorePreviewPage() {
            const {
                teamsArray: _0xe7e004,
                studentsArray: _0x33d2fd
            } = getProvisionalScores();
            return "\n              <div class=\"page space-y-12\">\n                  <div class=\"bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 rounded-md\" role=\"alert\">\n                      <p class=\"font-bold\">Score Preview Mode</p>\n                      <p>This page shows the projected scores including results that are 'Ready to Publish'. These are not the live public scores.</p>\n                  </div>\n                  <div>\n                      <h1 class=\"text-3xl font-bold text-gray-900 mb-6\">Provisional Team Standings</h1>\n                      <div class=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6\">\n                          " + _0xe7e004.map((_0x39e398, _0x21eeab) => {
                const _0x5c8066 = ['text-yellow-400', "text-gray-400", "text-yellow-600", 'text-blue-400'];
                const _0x37b30b = ["fa-crown", 'fa-medal', 'fa-award', "fa-star"];
                return "\n                          <div class=\"bg-white shadow-lg rounded-xl p-6\">\n                              <div class=\"flex items-center justify-between\">\n                                  <h2 class=\"text-xl font-bold text-gray-800\">" + _0x39e398.name + "</h2>\n                                  " + (_0x21eeab < 0x4 ? "<i class=\"fas " + _0x37b30b[_0x21eeab] + " text-2xl " + _0x5c8066[_0x21eeab] + "\"></i>" : '') + "\n                              </div>\n                              <p class=\"text-5xl font-extrabold text-indigo-600 mt-4\">" + _0x39e398.totalPoints + "</p>\n                              <p class=\"text-gray-500 mt-1\">Total Points</p>\n                          </div>";
            }).join('') + "\n                      </div>\n                  </div>\n                  <div>\n                      <h2 class=\"text-3xl font-bold text-gray-900 mb-6\">Provisional Category-wise Scores</h2>\n                      <div class=\"bg-white shadow-lg rounded-xl overflow-x-auto\">\n                         <table class=\"min-w-full divide-y divide-gray-200\">\n                              <thead class=\"bg-gray-50\">\n                                  <tr>\n                                      <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Team</th>\n                                      " + CATEGORIES.map(_0x50ba94 => "<th class=\"px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider\">" + _0x50ba94 + "</th>").join('') + "\n                                  </tr>\n                              </thead>\n                              <tbody class=\"bg-white divide-y divide-gray-200\">\n                                  " + _0xe7e004.map(_0x45eef5 => "\n                                  <tr>\n                                      <td class=\"px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900\">" + _0x45eef5.name + "</td>\n                                      " + CATEGORIES.map(_0x540f74 => "<td class=\"px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center\">" + (_0x45eef5.categoryPoints[_0x540f74] || 0x0) + "</td>").join('') + "\n                                  </tr>\n                                  ").join('') + "\n                              </tbody>\n                         </table>\n                      </div>\n                  </div>\n                  <div>\n                      <h2 class=\"text-3xl font-bold text-gray-900 mb-6\">Provisional Top Scorers</h2>\n                           <div class=\"bg-white shadow-lg rounded-xl overflow-hidden\">\n                                <div class=\"overflow-x-auto\">\n                                    <table class=\"min-w-full divide-y divide-gray-200\">\n                                          <thead class=\"bg-gray-50\">\n                                              <tr>\n                                                  <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Rank</th>\n                                                  <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Student</th>\n                                                  <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Team</th>\n                                                  <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Category</th>\n                                                  <th class=\"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider\">Points</th>\n                                              </tr>\n                                         </thead>\n                                         <tbody class=\"bg-white divide-y divide-gray-200\">\n                                             " + _0x33d2fd.slice(0x0, 0x64).map((_0xa220e, _0x1541d1) => "\n                                             <tr class=\"hover:bg-gray-50\">\n                                                 <td class=\"px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900\">" + (_0x1541d1 + 0x1) + "</td>\n                                                 <td class=\"px-6 py-4 whitespace-nowrap text-sm font-medium text-indigo-600\"><a href=\"#/student/" + _0xa220e.id + "\" class=\"hover:underline\">" + _0xa220e.name + "</a></td>\n                                                 <td class=\"px-6 py-4 whitespace-nowrap text-sm text-gray-500\">" + (appData.teams[_0xa220e.teamId]?.["name"] || "N/A") + "</td>\n                                                 <td class=\"px-6 py-4 whitespace-nowrap text-sm text-gray-500\">" + _0xa220e.category + "</td>\n                                                 <td class=\"px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900\">" + (_0xa220e.totalPoints || 0x0) + "</td>\n                                             </tr>\n                                             ").join('') + "\n                                         </tbody>\n                                    </table>\n                                </div>\n                           </div>\n                  </div>\n              </div>\n            ";
        }

/**
 * Populates the "recent results" list in the Upload Results tab.
 * Called by renderAdminTab() after the HTML shell is injected.
 */
function loadRecentResults() {
    const listContainer = document.getElementById("recent-results-list");
    if (!listContainer) return;

    const results = getDataAsArray("results").sort((a, b) => b.timestamp - a.timestamp);

    if (results.length === 0) {
        listContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No results have been added yet.</p>';
        return;
    }

    listContainer.innerHTML = results.map(result => `
        <div class="border rounded-lg p-4 bg-gray-50">
            <div class="flex justify-between items-start">
                <div>
                    <p class="font-bold text-gray-800">${result.programName}</p>
                    <p class="text-sm text-gray-500">${result.category} • ${result.stageType === 'non-stage' ? 'Non-Stage' : 'Stage'}</p>
                </div>
                <div class="flex items-center gap-2">
                    <button class="edit-result-btn text-blue-500 hover:text-blue-700" data-id="${result.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="delete-btn text-red-500 hover:text-red-700" data-id="${result.id}" data-collection="results">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Populates the items list for Students / Teams / Programs / Penalty admin tabs.
 * Called by renderAdminTab() after the HTML shell is injected.
 * @param {string} collection  e.g. "students", "teams", "programs", "penalty"
 */
function loadItemsList(collection) {
    const container = document.getElementById("items-list");
    if (!container) return;

    if (collection === 'penalty') collection = 'teamPenalties';

    if (collection === 'teamPenalties') {
        const penalties = getDataAsArray('teamPenalties').sort((a, b) => b.createdAt - a.createdAt);
        if (penalties.length === 0) {
            container.innerHTML = '<p class="text-gray-500 text-center py-4">No penalties have been applied yet.</p>';
            return;
        }
        container.innerHTML = penalties.map(penalty => `
            <div class="flex justify-between items-center bg-red-50 p-3 rounded-lg">
                <div>
                    <p class="font-medium text-gray-800">
                        -${penalty.points} points to
                        <strong>${appData.teams[penalty.teamId]?.name || 'Unknown Team'}</strong>
                    </p>
                    <p class="text-sm text-gray-500">Reason: ${penalty.reason}</p>
                </div>
                <button class="delete-btn text-red-500 hover:text-red-700"
                    data-id="${penalty.id}" data-collection="teamPenalties">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
        return;
    }

    const items = getDataAsArray(collection).sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    if (items.length === 0) {
        container.innerHTML = `<p class="text-gray-500 text-center py-4">No ${collection} have been added yet.</p>`;
        return;
    }

    container.innerHTML = items.map(item => `
        <div class="flex justify-between items-center bg-gray-50 p-3 rounded-lg">
            <div>
                <p class="font-medium text-gray-800">${item.name}</p>
                <p class="text-sm text-gray-500">
                    ${collection === "students" ? `Chest No: ${item.chestNo} • ` : ''}
                    ${item.category || ''}
                    ${collection === "programs" ? ' • ' + (item.stageType === 'non-stage' ? 'Non-Stage' : 'Stage') : ''}
                    ${item.teamId ? ' • ' + (appData.teams[item.teamId]?.name || 'N/A') : ''}
                </p>
            </div>
            <button class="delete-btn text-red-500 hover:text-red-700"
                data-id="${item.id}" data-collection="${collection}">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');
}
