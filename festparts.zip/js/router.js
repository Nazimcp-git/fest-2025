// js/router.js
// Hash-based single-page-app router.
// Maps URL hashes to render functions and sets up per-page listeners.

/** Builds navigation link HTML. Mobile variant uses block layout. */
const generateNavLinks = (mobile = false) => {
  const cls = mobile
    ? "block px-4 py-3 text-base font-medium"
    : "px-3 py-2 rounded-md text-sm font-medium";

  const links = `
    <a href="#/" class="nav-link text-gray-600 hover:bg-indigo-600 hover:text-white ${cls}">Home</a>
    <a href="#/results" class="nav-link text-gray-600 hover:bg-indigo-600 hover:text-white ${cls}">Results</a>
    <a href="live.html" class="nav-link text-gray-600 hover:bg-indigo-600 hover:text-white ${cls}">Live</a>
    <a href="#/leaderboard" class="nav-link text-gray-600 hover:bg-indigo-600 hover:text-white ${cls}">Leaderboard</a>
    <a href="#/search" class="nav-link text-gray-600 hover:bg-indigo-600 hover:text-white ${cls}">Search</a>
  `;

  const adminLink = currentUser
    ? `<a href="#/admin" class="nav-link text-gray-600 hover:bg-indigo-600 hover:text-white ${cls}">Admin</a>
       <button id="logout-btn" class="${mobile ? 'w-full text-left ' : ''}bg-red-500 text-white ${cls}">Logout</button>`
    : `<a href="#/admin" class="nav-link text-gray-600 hover:bg-indigo-600 hover:text-white ${cls}">Admin Login</a>`;

  return links + adminLink;
};

/** Helper: generates category <option> elements */
const categoryOptions = () =>
  '<option value="">Select Category</option>' +
  CATEGORIES.map(c => `<option value="${c}">${c}</option>`).join('');

/**
 * Main router. Called on hash change and after data sync.
 * @param {boolean} softUpdate  true = only refresh content, keep shell HTML
 */
async function router(softUpdate = false) {
  const hash    = window.location.hash.slice(1) || '/';
  const appEl   = document.getElementById("app");

  if (!softUpdate) {
    // Full shell re-render
    appEl.innerHTML = `
      <div class="min-h-screen bg-gray-100 flex flex-col">
        <nav class="bg-white shadow-md sticky top-0 z-50">
          <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
              <a href="#/" class="font-bold text-xl text-indigo-600">
                <i class="fas fa-trophy mr-2"></i>PORU 2K25
              </a>
              <div class="hidden md:block">
                <div id="desktop-nav" class="ml-10 flex items-baseline space-x-4">
                  ${generateNavLinks()}
                </div>
              </div>
              <div class="md:hidden">
                <button id="mobile-menu-btn" class="text-gray-600 hover:text-indigo-600 p-2 rounded-md">
                  <i class="fas fa-bars text-xl"></i>
                </button>
              </div>
            </div>
          </div>
          <div id="mobile-nav-container" class="md:hidden bg-white border-t border-gray-200"></div>
        </nav>
        <main id="main-content" class="py-10 flex-grow remoss">
          <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 px-6">
            <div class="flex justify-center items-center p-16"><div class="loader"></div></div>
          </div>
        </main>
        <p style="text-align:center; color:gray; margin-bottom:10px; font-size:14px;">
          © Copyright Owned Nazim Cp
        </p>
        <div id="modal-container" class="hidden"></div>
      </div>
    `;
  } else {
    // Soft update: refresh nav active state only
    const desktopNav = document.getElementById('desktop-nav');
    if (desktopNav) desktopNav.innerHTML = generateNavLinks();

    if (hash.startsWith('/admin') && document.getElementById("admin-tabs")) {
      const activeTab = document.querySelector(".admin-tab.active");
      renderAdminTab(activeTab ? activeTab.dataset.tab : 'dashboard');
      return;
    }
  }

  const mainContent = appEl.querySelector("#main-content");
  if (!mainContent) return;

  // Highlight active nav link
  const currentHash = window.location.hash.slice(1) || '/';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute("href").slice(1);
    const active = currentHash === href || (currentHash === '' && href === '/');
    link.classList.toggle("bg-indigo-600", active);
    link.classList.toggle("text-white", active);
    link.classList.toggle("text-gray-600", !active);
  });

  // Route to render function
  let renderFn;
  if (hash.startsWith('/student/')) {
    const studentId = hash.split('/')[2];
    renderFn = () => renderStudentPage(studentId);
  } else {
    const routes = {
      '/':           renderHomePage,
      '/results':    renderResultsPage,
      '/leaderboard':renderLeaderboardPage,
      '/search':     renderSearchPage,
      '/admin':      renderAdminPage
    };
    renderFn = routes[hash] || renderNotFoundPage;
  }

  mainContent.innerHTML = await renderFn();
  attachPageEventListeners(hash);
}

/**
 * Attaches route-specific DOM event listeners after a page renders.
 * @param {string} hash  current URL hash path
 */
function attachPageEventListeners(hash) {
  if (hash.startsWith("/admin")) {
    document.getElementById("admin-tabs")?.addEventListener("click", e => {
      if (e.target.matches(".admin-tab")) {
        activeAdminTab = e.target.dataset.tab;
        renderAdminTab(activeAdminTab);
      }
    });

    const adminContent = document.getElementById("admin-tab-content");
    adminContent?.addEventListener("submit",  handleAdminFormSubmit);
    adminContent?.addEventListener("change",  handleAdminFormChange);
    adminContent?.addEventListener("click",   handleAdminListClick);

    adminContent?.addEventListener("click", e => {
      if (e.target.id === "add-participant-btn")        addParticipantToTempList();
      if (e.target.matches(".remove-participant-btn"))  removeParticipantFromTempList(e.target.dataset.index);
      if (e.target.id === "download-student-template")  downloadTemplate("student");
      if (e.target.id === "download-program-template")  downloadTemplate('program');
      if (e.target.matches("#status-filter-container .category-filter-btn")) {
        activeStatusFilter = e.target.dataset.status;
        renderAdminTab('status');
      }
      if (e.target.matches("#category-filter-container .category-filter-btn")) {
        activeStatusCategoryFilter = e.target.dataset.category;
        renderAdminTab('status');
      }
      if (e.target.matches("#stage-filter-container .category-filter-btn")) {
        activeStatusStageFilter = e.target.dataset.stage;
        renderAdminTab('status');
      }
    });

    adminContent?.addEventListener('input', e => {
      if (e.target.id === 'publish-search-input') {
        const term = e.target.value.toLowerCase();
        document.querySelectorAll('#publish-list .program-item-container').forEach(item => {
          item.style.display = item.dataset.programName.includes(term) ? 'block' : 'none';
        });
      }
    });
  }

  if (hash === '/search') {
    document.getElementById('profile-search-form')?.addEventListener('submit', handleProfileSearch);
  }

  if (hash === "/results") {
    document.getElementById("main-content")?.addEventListener("submit", e => {
      if (e.target.id === "results-search-form") {
        e.preventDefault();
        const val = document.getElementById("results-search-input").value;
        const activeStageFilter = document.querySelector("#results-stage-filter-container .active")?.dataset.stage || 'All';
        renderResultsPage(val, activeStageFilter).then(html => {
          document.getElementById("main-content").innerHTML = html;
        });
      }
    });

    document.getElementById("main-content")?.addEventListener("click", e => {
      if (e.target.matches("#results-stage-filter-container .category-filter-btn")) {
        const stage = e.target.dataset.stage;
        const val = document.getElementById("results-search-input")?.value || '';
        renderResultsPage(val, stage).then(html => {
          document.getElementById("main-content").innerHTML = html;
        });
      }
    });
  }

  if (hash === "/leaderboard") {
    document.getElementById("leaderboard-filter-container")?.addEventListener("click", e => {
      if (e.target.classList.contains("category-filter-btn")) {
        renderLeaderboardPage(e.target.dataset.category).then(html => {
          document.getElementById("main-content").innerHTML = html;
        });
      }
    });
  }
}
