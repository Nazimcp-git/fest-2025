// js/state.js
// Shared application state. All modules read/write these variables.
// Keep mutations minimal and intentional.

let currentUser = null;

let appData = {
  teams:               {},
  students:            {},
  programs:            {},
  results:             {},
  pointsConfig:        {},
  groupPointsConfig:   {},
  teamPointsConfig:    {},
  teamDirectScores:    {},
  teamPenalties:       {}
};

let isInitialLoad       = true;
let tempParticipants    = [];
let activeAdminTab      = "dashboard";
let editingResultId     = null;
let activeStatusFilter  = 'All';
let activeStatusCategoryFilter = 'All';
let activeStatusStageFilter = 'All';
